// --- Fluxee v5.0: Auto-Moderator Logic ---

// UI Elements
const openAnalyticsBtn = document.getElementById('openAnalyticsBtn');
const openDesignerBtn = document.getElementById('openDesignerBtn');
const toastContainer = document.getElementById('toast-container');

// Caps Filter Elements
const enableCapsFilter = document.getElementById('enableCapsFilter');
const minCapsLength = document.getElementById('minCapsLength');
const capsThreshold = document.getElementById('capsThreshold');
const capsWarningMsg = document.getElementById('capsWarningMsg');

// Word Filter Elements
const enableWordFilter = document.getElementById('enableWordFilter');
const wordInput = document.getElementById('wordInput');
const addWordBtn = document.getElementById('addWordBtn');
const wordTagsContainer = document.getElementById('wordTagsContainer');
const wordWarningMsg = document.getElementById('wordWarningMsg');

// Paragraphs Filter Elements
const enableParagraphsFilter = document.getElementById('enableParagraphsFilter');
const maxChars = document.getElementById('maxChars');
const maxNewlines = document.getElementById('maxNewlines');
const paragraphsWarningMsg = document.getElementById('paragraphsWarningMsg');

// Symbols Filter Elements
const enableSymbolsFilter = document.getElementById('enableSymbolsFilter');
const minSymbolsLength = document.getElementById('minSymbolsLength');
const symbolsThreshold = document.getElementById('symbolsThreshold');
const symbolsWarningMsg = document.getElementById('symbolsWarningMsg');

// Exclusion Toggles (Global)
const excludeSubscribers = document.getElementById('excludeSubscribers');
const excludeCreators = document.getElementById('excludeCreators');

// Links Filter Elements
const enableLinksFilter = document.getElementById('enableLinksFilter');
const linksWarningMsg = document.getElementById('linksWarningMsg');
const whitelistInput = document.getElementById('whitelistInput');
const addWhitelistBtn = document.getElementById('addWhitelistBtn');
const whitelistContainer = document.getElementById('whitelistContainer');

// State
let currentLang = 'en';
let whitelistedLinksList = ['fansly.com', 'twitter.com'];
let bannedWordsList = [];
const hardcodedWhitelist = ['fansly.com'];

async function loadState() {
    if (typeof chrome === 'undefined' || !chrome.storage) {
        applyLanguage('en');
        initHandlers();
        return;
    }
    const result = await chrome.storage.local.get([
        'currentLang',
        'enableCapsFilter',
        'minCapsLength',
        'capsThreshold',
        'capsWarningMsg',
        'excludeSubscribers',
        'excludeCreators',
        'enableLinksFilter',
        'linksWarningMsg',
        'whitelistedLinks',
        'enableWordFilter',
        'bannedWords',
        'wordWarningMsg',
        'enableParagraphsFilter',
        'maxChars',
        'maxNewlines',
        'paragraphsWarningMsg',
        'enableSymbolsFilter',
        'minSymbolsLength',
        'symbolsThreshold',
        'symbolsWarningMsg'
    ]);

    currentLang = result.currentLang || 'en';

    // UI Synchronization
    if (enableCapsFilter) enableCapsFilter.checked = !!result.enableCapsFilter;
    if (minCapsLength) minCapsLength.value = result.minCapsLength || 5;
    if (capsThreshold) capsThreshold.value = result.capsThreshold || 70;
    if (capsWarningMsg) capsWarningMsg.value = result.capsWarningMsg || "";

    // Exclusions
    if (excludeSubscribers) excludeSubscribers.checked = !!result.excludeSubscribers; // Default false
    if (excludeCreators) excludeCreators.checked = !!result.excludeCreators; // Default false

    // Links Filter
    if (enableLinksFilter) enableLinksFilter.checked = !!result.enableLinksFilter;
    if (linksWarningMsg) linksWarningMsg.value = result.linksWarningMsg || "";
    whitelistedLinksList = result.whitelistedLinks || ['fansly.com', 'twitter.com'];

    // Word Filter
    if (enableWordFilter) enableWordFilter.checked = !!result.enableWordFilter;
    if (wordWarningMsg) wordWarningMsg.value = result.wordWarningMsg || "";

    // Migration logic: String to Array for bannedWords
    if (typeof result.bannedWords === 'string') {
        bannedWordsList = result.bannedWords.split(',').map(w => w.trim().toLowerCase()).filter(w => w.length > 0);
    } else {
        bannedWordsList = result.bannedWords || [];
    }

    // Paragraphs Filter
    if (enableParagraphsFilter) enableParagraphsFilter.checked = !!result.enableParagraphsFilter;
    if (maxChars) maxChars.value = result.maxChars || 250;
    if (maxNewlines) maxNewlines.value = (result.maxNewlines === undefined) ? 5 : result.maxNewlines;
    if (paragraphsWarningMsg) paragraphsWarningMsg.value = result.paragraphsWarningMsg || "";

    // Symbols Filter
    if (enableSymbolsFilter) enableSymbolsFilter.checked = !!result.enableSymbolsFilter;
    if (minSymbolsLength) minSymbolsLength.value = result.minSymbolsLength || 10;
    if (symbolsThreshold) symbolsThreshold.value = result.symbolsThreshold || 50;
    if (symbolsWarningMsg) symbolsWarningMsg.value = result.symbolsWarningMsg || "";

    // Ensure hardcoded items are present
    hardcodedWhitelist.forEach(item => {
        if (!whitelistedLinksList.includes(item)) whitelistedLinksList.unshift(item);
    });

    renderWhitelist();
    renderWordTags();

    applyLanguage(currentLang);
    initHandlers();
}

function saveState() {
    const data = {
        enableCapsFilter: enableCapsFilter.checked,
        minCapsLength: parseInt(minCapsLength.value) || 5,
        capsThreshold: parseInt(capsThreshold.value) || 70,
        capsWarningMsg: capsWarningMsg.value,
        excludeSubscribers: excludeSubscribers.checked,
        excludeCreators: excludeCreators.checked,
        enableLinksFilter: enableLinksFilter.checked,
        linksWarningMsg: linksWarningMsg.value,
        whitelistedLinks: whitelistedLinksList,
        enableWordFilter: enableWordFilter.checked,
        bannedWords: bannedWordsList,
        wordWarningMsg: wordWarningMsg.value,
        enableParagraphsFilter: enableParagraphsFilter.checked,
        maxChars: parseInt(maxChars.value) || 250,
        maxNewlines: parseInt(maxNewlines.value) || 0,
        paragraphsWarningMsg: paragraphsWarningMsg.value,
        enableSymbolsFilter: enableSymbolsFilter.checked,
        minSymbolsLength: parseInt(minSymbolsLength.value) || 10,
        symbolsThreshold: parseInt(symbolsThreshold.value) || 50,
        symbolsWarningMsg: symbolsWarningMsg.value
    };
    chrome.storage.local.set(data);
}

function renderWhitelist() {
    if (!whitelistContainer) return;
    whitelistContainer.innerHTML = '';

    whitelistedLinksList.forEach((domain, index) => {
        const isHardcoded = hardcodedWhitelist.includes(domain);
        const pill = document.createElement('span');
        pill.className = 'tag-pill';
        if (!isHardcoded) pill.style.cursor = 'pointer';

        pill.innerHTML = `${domain} ${isHardcoded ? '' : '<span class="delete-x" style="margin-left: 5px; font-size: 14px; color: #ff5252;">×</span>'}`;

        if (!isHardcoded) {
            pill.onclick = () => {
                whitelistedLinksList.splice(index, 1);
                saveState();
                renderWhitelist();
            };
        }
        whitelistContainer.appendChild(pill);
    });
}

function renderWordTags() {
    if (!wordTagsContainer) return;
    wordTagsContainer.innerHTML = '';

    bannedWordsList.forEach((word, index) => {
        const pill = document.createElement('span');
        pill.className = 'tag-pill';
        pill.style.cursor = 'pointer';

        pill.innerHTML = `${word} <span class="delete-x" style="margin-left: 5px; font-size: 14px; color: #ff5252;">×</span>`;

        pill.onclick = () => {
            bannedWordsList.splice(index, 1);
            saveState();
            renderWordTags();
        };
        wordTagsContainer.appendChild(pill);
    });
}

function applyLanguage(lang) {
    currentLang = lang;
    const trans = uiTranslations[lang];
    if (!trans) return;

    document.querySelectorAll('.lang-flag').forEach(flag => {
        flag.classList.toggle('active', flag.dataset.lang === lang);
    });

    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (trans[key]) el.innerText = trans[key];
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.dataset.i18nPlaceholder;
        if (trans[key]) el.placeholder = trans[key];
    });
}

function initHandlers() {
    if (openAnalyticsBtn) {
        openAnalyticsBtn.onclick = () => {
            window.location.href = 'analytics.html';
        };
    }
    if (openDesignerBtn) {
        openDesignerBtn.onclick = () => {
            window.location.href = 'designer.html';
        };
    }

    document.querySelectorAll('.lang-flag').forEach(flag => {
        flag.onclick = () => {
            applyLanguage(flag.dataset.lang);
            chrome.storage.local.set({ currentLang: flag.dataset.lang });
        };
    });

    // Caps Filter State Listeners
    if (enableCapsFilter) enableCapsFilter.addEventListener('change', saveState);
    if (minCapsLength) minCapsLength.addEventListener('input', saveState);
    if (capsThreshold) capsThreshold.addEventListener('input', saveState);
    if (capsWarningMsg) capsWarningMsg.addEventListener('input', saveState);

    // Exclusion Listeners
    if (excludeSubscribers) excludeSubscribers.addEventListener('change', saveState);
    if (excludeCreators) excludeCreators.addEventListener('change', saveState);

    // Word Filter Listeners
    if (enableWordFilter) enableWordFilter.addEventListener('change', saveState);
    if (wordWarningMsg) wordWarningMsg.addEventListener('input', saveState);

    if (addWordBtn && wordInput) {
        addWordBtn.addEventListener('click', () => {
            const word = wordInput.value.trim().toLowerCase();
            if (word && !bannedWordsList.includes(word)) {
                bannedWordsList.push(word);
                wordInput.value = '';
                saveState();
                renderWordTags();
            }
        });

        wordInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') addWordBtn.click();
        });
    }

    // Paragraphs Filter Listeners
    if (enableParagraphsFilter) enableParagraphsFilter.addEventListener('change', saveState);
    if (maxChars) maxChars.addEventListener('input', saveState);
    if (maxNewlines) maxNewlines.addEventListener('input', saveState);
    if (paragraphsWarningMsg) paragraphsWarningMsg.addEventListener('input', saveState);

    // Symbols Filter Listeners
    if (enableSymbolsFilter) enableSymbolsFilter.addEventListener('change', saveState);
    if (minSymbolsLength) minSymbolsLength.addEventListener('input', saveState);
    if (symbolsThreshold) symbolsThreshold.addEventListener('input', saveState);
    if (symbolsWarningMsg) symbolsWarningMsg.addEventListener('input', saveState);

    // Links Filter Listeners
    if (enableLinksFilter) enableLinksFilter.addEventListener('change', saveState);
    if (linksWarningMsg) linksWarningMsg.addEventListener('input', saveState);

    if (addWhitelistBtn && whitelistInput) {
        addWhitelistBtn.addEventListener('click', () => {
            const domain = whitelistInput.value.trim().toLowerCase();
            if (domain && !whitelistedLinksList.includes(domain)) {
                whitelistedLinksList.push(domain);
                whitelistInput.value = '';
                saveState();
                renderWhitelist();
            }
        });

        whitelistInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') addWhitelistBtn.click();
        });
    }
}

function showToast(message, duration = 3000) {
    if (!toastContainer) return;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>${message}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

document.addEventListener('DOMContentLoaded', loadState);
