// --- Chrome Storage Fallback ---
const chromeStorageLocal = {
    get: (keys, callback) => {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(keys, callback);
        } else {
            const result = {};
            keys.forEach(key => {
                const val = localStorage.getItem(key);
                try {
                    result[key] = val ? JSON.parse(val) : undefined;
                } catch (e) {
                    result[key] = val;
                }
            });
            setTimeout(() => callback(result), 0);
        }
    },
    set: (data, callback) => {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set(data, callback);
        } else {
            Object.keys(data).forEach(key => {
                localStorage.setItem(key, JSON.stringify(data[key]));
            });
            if (callback) setTimeout(callback, 0);
        }
    }
};

const applyDesignerBtn = document.getElementById('applyDesignerBtn');
const openAnalyticsBtn = document.getElementById('openAnalyticsBtn');
const menuSelect = document.getElementById('menuSelect');
const menuNameInput = document.getElementById('menuName');
const vibeBtns = document.querySelectorAll('.vibe-btn');
const layoutBtns = document.querySelectorAll('.layout-btn');
const toastContainer = document.getElementById('toast-container');
const designerInput = document.getElementById('designerInput');

const syntaxBtns = document.querySelectorAll('.syntax-btn');
const customVibeName = document.getElementById('customVibeName');
const customVibeTemplate = document.getElementById('customVibeTemplate');
const saveCustomVibeBtn = document.getElementById('saveCustomVibeBtn');
const presetsGrid = document.getElementById('presetsGrid');

const confirmModalOverlay = document.getElementById('confirm-modal-overlay');
const confirmModalMessage = document.getElementById('confirm-modal-message');
const confirmModalYes = document.getElementById('confirm-modal-yes');
const confirmModalNo = document.getElementById('confirm-modal-no');

let editingVibeId = null;
const itemSeparatorSection = document.getElementById('itemSeparatorSection');
const sepBtns = document.querySelectorAll('.sep-btn');

let currentDesignerVibe = 'classic';
let currentDesignerLayout = 'list';
let currentSyntaxStyle = 'default';
let currentItemSeparator = ' | ';
let currentLang = 'en';
let menus = {};
let customVibes = [];
let customEmojis = [];

const VTE_THEMES = {
    classic: { bullet: '' },
    pipe: { bullet: '' },
    bracket: { bullet: '' },
    ribbon: { bullet: '' },
    grid: { bullet: '' }
};

const ASSET_EMOJIS = ['⭐', '✨', '💖', '🔥', '💎', '🍬', '🍭', '🎀', '🦄', '🌈', '💋', '😈', '🔞', '💰', '💸', '🎁', '⚡', '🌟', '🍀', '🌸', '🐾', '🍒', '🍓', '🥂', '🍿', '🤳', '💄', '👛', '👠', '👑', '🦋', '📸', '💌', '🖤', '🍦', '🌌'];
const ASSET_DECORS = [
    '━━━━━━━',
    '───────',
    '••••••••',
    '◌⑅⃝●♡⋆♡●⑅⃝◌',
    '══✿══╡°˖✧✿✧˖°╞══✿══',
    '⊱ ─── {⋅. ✯ .⋅} ─── ⊰',
    '╔══*.·:·.☽✧ ✦ ✧☾.·:·.*══╗',
    '≿━━━━━༺❀༻━━━━━≾',
    '───── ⋆⋅☆⋅⋆ ─────',
    '━━━ ˖°˖ ☾☆☽ ˖°˖ ━━━',
    '⋅•⋅⋅•⋅⊰⋅•⋅⋅•⋅⋅•⋅⋅•⋅∙∘☽༓☾∘∙•⋅⋅⋅•⋅⋅⊰⋅•⋅⋅•⋅⋅•⋅⋅•⋅',
    '∘₊✧──────✧₊∘',
    '૮꒰˵•ﻌ•˵꒱ა┄┄┄┄૮꒰˵•ﻌ•˵꒱ა',
    '✯¸.•´*¨`*•✿ ✿•*`¨`*•.¸✯',
    '•❅──────✧❅✦❅✧──────❅•',
];
// --- Custom Notification Helpers ---
function showToast(message, duration = 3000) {
    if (!toastContainer) return;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>${message}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

function showConfirm(message, onConfirm) {
    if (!confirmModalOverlay) return;
    confirmModalMessage.textContent = message;
    confirmModalOverlay.style.display = 'flex';

    const cleanup = () => {
        confirmModalOverlay.style.display = 'none';
        confirmModalYes.onclick = null;
        confirmModalNo.onclick = null;
    };

    confirmModalYes.onclick = () => {
        cleanup();
        if (onConfirm) onConfirm();
    };

    confirmModalNo.onclick = () => {
        cleanup();
    };
}

function applyLanguage(lang) {
    currentLang = lang;
    const trans = uiTranslations[lang];
    if (!trans) return;

    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (trans[key]) el.innerText = trans[key];
    });

    document.querySelectorAll('.lang-flag').forEach(flag => {
        flag.classList.toggle('active', flag.dataset.lang === lang);
    });

    updateDesignerPreview();
}

// Smart Parser to extract label and price
function parseTipLine(line) {
    const trimmed = line.trim();
    if (!trimmed) return null;

    // Regex to find price: $10, 10$, (10), [10], 10 - handles decimals too
    const priceRegex = /(\$?\d+(?:[.,]\d+)?\$?|\(\d+\)|\[\d+\])/;
    const match = trimmed.match(priceRegex);

    if (!match) return { label: trimmed, price: '', original: trimmed };

    const rawPrice = match[0];
    const cleanPrice = rawPrice.replace(/[$\(\)\[\]]/g, '').trim();

    // Label is whatever is left after removing the price and some separator noise
    let label = trimmed.replace(rawPrice, '')
        // Aggressive cleaning: strip markdown stars, underscores, brackets, pipes, bullets, and emojis from edges
        .replace(/^[*_~|\[\]\(\){}:\-•/\s\uD800-\uDBFF\uDC00-\uDFFF]+/, '')
        .replace(/[*_~|\[\]\(\){}:\-•/\s\uD800-\uDBFF\uDC00-\uDFFF]+$/, '')
        .trim();

    if (!label) label = 'Tip';

    return { label, price: cleanPrice, original: trimmed };
}

function formatTipLine(item, theme) {
    const { label, price, original } = item;

    // "Default" now preserves the user's raw input exactly
    if (currentSyntaxStyle === 'default') {
        return original;
    }

    if (!price) return `${theme.bullet} ${label}`.trim();

    switch (currentSyntaxStyle) {
        case 'pipe':
            return `${theme.bullet} ${label} | $${price}`.trim();
        case 'bracket':
            return `${theme.bullet} [ $${price} ] ${label}`.trim();
        default:
            return original;
    }
}

function updateDesignerPreview() {
    const rawText = designerInput.value.trim();
    if (!rawText) {
        designerPreview.innerHTML = '<span style="color: #888; font-style: italic;">Preview will appear here...</span>';
        return;
    }

    const theme = VTE_THEMES[currentDesignerVibe] || { bullet: '' };

    // Show/Hide Item Separator section
    if (itemSeparatorSection) {
        itemSeparatorSection.style.display = (currentDesignerLayout === 'list') ? 'none' : 'block';
    }

    const rawLines = rawText.split('\n').filter(l => l.trim());
    const items = rawLines.map(parseTipLine).filter(Boolean);

    let previewLines = [];
    const groupBy = (currentDesignerLayout === 'price');

    const customVibe = customVibes.find(v => v.id === currentDesignerVibe);

    if (groupBy) {
        const groups = {};
        items.forEach(item => {
            const p = item.price || 'Other';
            if (!groups[p]) groups[p] = [];
            groups[p].push(item);
        });

        Object.keys(groups).sort((a, b) => parseFloat(a) - parseFloat(b)).forEach(price => {
            const header = (price === 'Other') ? '--- ✨ ---' : `--- 💸 $${price} ---`;
            previewLines.push(header);
            groups[price].forEach(item => {
                if (customVibe) {
                    let line = customVibe.template
                        .replace('{icon}', theme.bullet || '')
                        .replace('{label}', item.label)
                        .replace('{price}', '') // Price is in header
                        .trim();
                    previewLines.push(line);
                } else {
                    // In group mode, respect the bullet
                    previewLines.push(`${theme.bullet} ${item.label}`);
                }
            });
        });
    } else {
        if (currentDesignerLayout === 'ribbon') {
            const ribbonLines = items.map(item => formatTipLine(item, theme));
            previewLines.push(ribbonLines.join(currentItemSeparator));
        } else if (currentDesignerLayout === 'grid') {
            let gridLine = '';
            items.forEach((item, idx) => {
                const formatted = formatTipLine(item, theme);
                gridLine += `[ ${formatted} ]` + currentItemSeparator;
                if ((idx + 1) % 2 === 0) {
                    previewLines.push(gridLine.trim().replace(new RegExp(currentItemSeparator.trim() + '$'), ''));
                    gridLine = '';
                }
            });
            if (gridLine) previewLines.push(gridLine.trim().replace(new RegExp(currentItemSeparator.trim() + '$'), ''));
        } else {
            items.forEach(item => {
                if (customVibe) {
                    let line = customVibe.template
                        .replace('{icon}', theme.bullet || '')
                        .replace('{label}', item.label)
                        .replace('{price}', item.price ? `$${item.price}` : '')
                        .trim();
                    previewLines.push(line);
                } else {
                    previewLines.push(formatTipLine(item, theme));
                }
            });
        }
    }

    const finalWrapped = previewLines.map(line => {
        // Word-aware wrap at 56 chars to simulate Fansly chat box limits
        const limit = 56;
        if (line.length <= limit) return line;

        const words = line.split(' ');
        let wrapped = '';
        let currentLine = '';

        words.forEach((word, idx) => {
            // Handle cases where a single word is longer than the limit
            if (word.length > limit) {
                if (currentLine) {
                    wrapped += currentLine.trim() + '\n';
                    currentLine = '';
                }
                wrapped += word + '\n';
                return;
            }

            if ((currentLine + word).length > limit) {
                wrapped += currentLine.trim() + '\n';
                currentLine = word + ' ';
            } else {
                currentLine += word + ' ';
            }
        });

        wrapped += currentLine.trim();
        return wrapped;
    }).join('\n');

    designerPreview.textContent = finalWrapped;
    designerPreview.className = 'fansly-chat-bubble';
}

// Events
vibeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        vibeBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const preset = btn.dataset.vibe;
        currentDesignerVibe = preset; // Keep id sync for custom vibes

        // Apply structural changes based on preset
        if (preset === 'classic') {
            currentDesignerLayout = 'list';
            currentSyntaxStyle = 'default';
        } else if (preset === 'pipe') {
            currentDesignerLayout = 'list';
            currentSyntaxStyle = 'pipe';
        } else if (preset === 'bracket') {
            currentDesignerLayout = 'list';
            currentSyntaxStyle = 'bracket';
        } else if (preset === 'ribbon') {
            currentDesignerLayout = 'ribbon';
            currentSyntaxStyle = 'default';
            currentItemSeparator = ' | ';
        } else if (preset === 'grid') {
            currentDesignerLayout = 'grid';
            currentSyntaxStyle = 'default';
            currentItemSeparator = '   ';
        }

        // Sync Layout/Syntax/Separator buttons UI
        layoutBtns.forEach(b => {
            b.classList.toggle('active', b.dataset.layout === currentDesignerLayout);
        });
        syntaxBtns.forEach(b => {
            b.classList.toggle('active', b.dataset.syntax === currentSyntaxStyle);
        });
        sepBtns.forEach(b => {
            b.classList.toggle('active', b.dataset.sep === currentItemSeparator);
        });

        updateDesignerPreview();
    });
});

layoutBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        layoutBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentDesignerLayout = btn.dataset.layout;
        updateDesignerPreview();
    });
});

syntaxBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        syntaxBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentSyntaxStyle = btn.dataset.syntax;
        updateDesignerPreview();
    });
});

sepBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        sepBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentItemSeparator = btn.dataset.sep;
        updateDesignerPreview();
    });
});

function saveCustomVibe() {
    const name = customVibeName.value.trim();
    const template = customVibeTemplate.value.trim();

    if (!name || !template) {
        showToast("Please enter both a Name and a Template! 💜");
        return;
    }

    if (editingVibeId) {
        const index = customVibes.findIndex(v => v.id === editingVibeId);
        if (index !== -1) {
            customVibes[index].name = name;
            customVibes[index].template = template;
        }
        editingVibeId = null;
        saveCustomVibeBtn.innerText = "Save Custom Vibe";
        saveCustomVibeBtn.style.background = "linear-gradient(135deg, #a78bfa, #8b5cf6)";
    } else {
        const newVibe = {
            id: 'cv_' + Date.now(),
            name: name,
            template: template
        };
        customVibes.push(newVibe);
    }

    chromeStorageLocal.set({ customVibes: customVibes }, () => {
        showToast("Custom Vibe saved! ✨");
        customVibeName.value = '';
        customVibeTemplate.value = '';
        renderCustomVibes();
    });
}

function renderCustomVibes() {
    if (!presetsGrid) return;
    presetsGrid.innerHTML = '';
    if (customVibes.length === 0) {
        presetsGrid.innerHTML = '<p class="hint-text" style="grid-column: 1/-1;">No custom presets yet.</p>';
        return;
    }

    customVibes.forEach(vibe => {
        const item = document.createElement('div');
        item.className = 'asset-item preset-item';

        const info = document.createElement('div');
        info.className = 'preset-info';
        info.innerHTML = `<div class="preset-name">${vibe.name}</div><div class="preset-template">${vibe.template}</div>`;

        const actions = document.createElement('div');
        actions.className = 'preset-actions';

        const editBtn = document.createElement('span');
        editBtn.className = 'edit-preset';
        editBtn.innerHTML = '✏️';
        editBtn.onclick = (e) => {
            e.stopPropagation();
            editCustomVibe(vibe.id);
        };

        const deleteBtn = document.createElement('span');
        deleteBtn.className = 'delete-preset';
        deleteBtn.innerHTML = '🗑️';
        deleteBtn.onclick = (e) => {
            e.stopPropagation();
            showConfirm("Are you sure you want to delete this preset? 🗑️", () => {
                customVibes = customVibes.filter(v => v.id !== vibe.id);
                chromeStorageLocal.set({ customVibes: customVibes }, renderCustomVibes);
            });
        };

        actions.appendChild(editBtn);
        actions.appendChild(deleteBtn);
        item.appendChild(info);
        item.appendChild(actions);

        item.onclick = () => {
            applyCustomVibeToSelection(vibe.template);
            showToast(`Applied ${vibe.name} to lines! ✨`);
        };

        presetsGrid.appendChild(item);
    });
}

function editCustomVibe(id) {
    const vibe = customVibes.find(v => v.id === id);
    if (!vibe) return;

    editingVibeId = vibe.id;
    customVibeName.value = vibe.name;
    customVibeTemplate.value = vibe.template;
    saveCustomVibeBtn.innerText = "Update Vibe";
    saveCustomVibeBtn.style.background = "linear-gradient(135deg, #fbbf24, #f59e0b)";

    // Switch to "New" tab automatically
    const customTabBtn = Array.from(assetTabs).find(t => t.dataset.tab === 'custom');
    if (customTabBtn) customTabBtn.click();

    // Smooth scroll to fields
    customVibeName.focus();
    customVibeName.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

saveCustomVibeBtn.addEventListener('click', saveCustomVibe);

designerInput.addEventListener('input', updateDesignerPreview);

function updateMenuDropdown() {
    const currentValue = menuSelect.value;
    menuSelect.innerHTML = '<option value="" data-i18n="newMenu">-- New Menu --</option>';

    Object.keys(menus).forEach(id => {
        const opt = document.createElement('option');
        opt.value = id;
        opt.textContent = menus[id].name;
        menuSelect.appendChild(opt);
    });

    menuSelect.value = currentValue;
    if (uiTranslations[currentLang] && uiTranslations[currentLang].newMenu) {
        menuSelect.options[0].textContent = uiTranslations[currentLang].newMenu;
    }
}

menuSelect.addEventListener('change', () => {
    const id = menuSelect.value;
    if (id && menus[id]) {
        menuNameInput.value = menus[id].name;
        designerInput.value = menus[id].content;
        updateDesignerPreview();
    } else {
        // Clear fields when "-- New Menu --" is selected
        menuNameInput.value = "";
        designerInput.value = "";
        updateDesignerPreview();
    }
});

applyDesignerBtn.addEventListener('click', () => {
    const finalContent = designerPreview.textContent;
    const menuName = menuNameInput.value.trim() || "Generated Menu";
    if (finalContent.includes('Preview will appear here')) return;

    chromeStorageLocal.get(['menus', 'currentMenuId'], (result) => {
        let localMenus = result.menus || {};
        let targetId = menuSelect.value || Date.now().toString();

        localMenus[targetId] = {
            name: menuName,
            content: finalContent
        };

        chromeStorageLocal.set({
            menus: localMenus,
            currentMenuId: targetId
        }, () => {
            menus = localMenus;
            updateMenuDropdown();
            menuSelect.value = targetId;
            showToast("Success! Menu saved and applied to Bot List. ✨");
        });
    });
});

openAnalyticsBtn.addEventListener('click', () => {
    window.location.href = 'analytics.html';
});

const openAutoModBtn = document.getElementById('openAutoModBtn');
if (openAutoModBtn) {
    openAutoModBtn.onclick = () => {
        window.location.href = 'automod.html';
    };
}

document.querySelectorAll('.lang-flag').forEach(flag => {
    flag.addEventListener('click', () => {
        applyLanguage(flag.dataset.lang);
        chromeStorageLocal.set({ currentLang: flag.dataset.lang });
    });
});

// Init
document.addEventListener('DOMContentLoaded', () => {
    chromeStorageLocal.get(['currentLang', 'menus', 'customVibes'], (result) => {
        menus = result.menus || {};
        customVibes = result.customVibes || [];
        customEmojis = result.customEmojis || [];
        if (result.currentLang) applyLanguage(result.currentLang);
        updateMenuDropdown();
        renderCustomVibes();
        refreshEmojisGrid();

        // Default to New Menu / Blank inputs as requested
        menuSelect.value = "";
        menuNameInput.value = "";
        designerInput.value = "";
        updateDesignerPreview();
    });
});

// Real-time Sync with Sidepanel
if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, namespace) => {
        if (namespace === 'local' && (changes.menus || changes.currentMenuId)) {
            chromeStorageLocal.get(['menus'], (result) => {
                menus = result.menus || {};
                updateMenuDropdown();
            });
        }
    });
}

const emojiGrid = document.getElementById('emojisGrid');
const decorGrid = document.getElementById('decorsGrid');
const assetTabs = document.querySelectorAll('.asset-tab');
const customAssetInput = document.getElementById('customAssetInput');
const saveCustomAssetBtn = document.getElementById('saveCustomAssetBtn');
const customEmojiInput = document.getElementById('customEmojiInput');
const saveCustomEmojiBtn = document.getElementById('saveCustomEmojiBtn');

function initStyleAssets() {
    refreshEmojisGrid();

    refreshDecorsGrid();

    // Tab Switching
    assetTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            assetTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            const target = tab.dataset.tab;
            const contents = document.querySelectorAll('.asset-tab-content');
            contents.forEach(c => c.style.display = 'none');

            const targetTab = document.getElementById(target + 'Tab');
            if (targetTab) {
                targetTab.style.display = 'flex';
            }

            if (target === 'presets') {
                renderCustomVibes();
            }
        });
    });

    saveCustomAssetBtn.addEventListener('click', saveCustomDecoration);
    saveCustomEmojiBtn.addEventListener('click', saveCustomEmoji);
}

function refreshEmojisGrid() {
    emojiGrid.innerHTML = '';

    // Render Static Emojis
    ASSET_EMOJIS.forEach(emoji => {
        const item = document.createElement('div');
        item.className = 'asset-item';
        item.textContent = emoji;
        item.onclick = () => insertAtCursor(emoji);
        emojiGrid.appendChild(item);
    });

    // Render Custom Emojis (with delete)
    chromeStorageLocal.get(['customEmojis'], (result) => {
        customEmojis = result.customEmojis || [];
        customEmojis.forEach(emoji => {
            const item = document.createElement('div');
            item.className = 'asset-item custom-emoji-item';

            const textSpan = document.createElement('span');
            textSpan.textContent = emoji;
            item.appendChild(textSpan);

            const deleteBtn = document.createElement('span');
            deleteBtn.className = 'delete-decor'; // Reuse same delete style
            deleteBtn.innerHTML = '🗑️';
            deleteBtn.style.fontSize = '12px';
            deleteBtn.onclick = (e) => {
                e.stopPropagation();
                showConfirm("Delete this custom emoji? 🗑️", () => {
                    customEmojis = customEmojis.filter(e => e !== emoji);
                    chromeStorageLocal.set({ customEmojis: customEmojis }, refreshEmojisGrid);
                });
            };
            item.appendChild(deleteBtn);

            item.onclick = () => insertAtCursor(emoji);
            emojiGrid.appendChild(item);
        });
    });
}

function saveCustomEmoji() {
    const text = customEmojiInput.value.trim();
    if (!text) return;

    chromeStorageLocal.get(['customEmojis'], (result) => {
        let emojis = result.customEmojis || [];
        if (!emojis.includes(text)) {
            emojis.push(text);
            chromeStorageLocal.set({ customEmojis: emojis }, () => {
                customEmojiInput.value = '';
                showToast("Emoji saved! ✨");
                refreshEmojisGrid();
                // Switch to Emojis tab
                assetTabs[0].click();
            });
        } else {
            showToast("Already in list! ✨");
        }
    });
}

function refreshDecorsGrid() {
    decorGrid.innerHTML = '';
    chromeStorageLocal.get(['customDecors'], (result) => {
        const customDecors = result.customDecors || [];

        // Render Static Decorations
        ASSET_DECORS.forEach(decor => {
            const item = document.createElement('div');
            item.className = 'asset-item decor-item';
            item.textContent = decor;
            item.onclick = () => insertAtCursor(decor);
            decorGrid.appendChild(item);
        });

        // Render Deletable Custom Decorations
        customDecors.forEach(decor => {
            const item = document.createElement('div');
            item.className = 'asset-item decor-item custom-decor-item';

            const textSpan = document.createElement('span');
            textSpan.textContent = decor;
            item.appendChild(textSpan);

            const deleteBtn = document.createElement('span');
            deleteBtn.className = 'delete-decor';
            deleteBtn.innerHTML = '🗑️';
            deleteBtn.onclick = (e) => {
                e.stopPropagation();
                showConfirm("Delete this custom decoration? 🗑️", () => {
                    const updated = customDecors.filter(d => d !== decor);
                    chromeStorageLocal.set({ customDecors: updated }, refreshDecorsGrid);
                });
            };
            item.appendChild(deleteBtn);

            item.onclick = () => insertAtCursor(decor);
            decorGrid.appendChild(item);
        });
    });
}

function saveCustomDecoration() {
    const text = customAssetInput.value.trim();
    if (!text) return;

    chromeStorageLocal.get(['customDecors'], (result) => {
        let decors = result.customDecors || [];
        if (!decors.includes(text)) {
            decors.push(text);
            chromeStorageLocal.set({ customDecors: decors }, () => {
                customAssetInput.value = '';
                showToast("Decoration saved to list! ✨");
                refreshDecorsGrid();
                // Switch to decorations tab to show the result
                assetTabs[1].click();
            });
        } else {
            showToast("Already in list! ✨");
        }
    });
}

function insertAtCursor(text) {
    const start = designerInput.selectionStart;
    const end = designerInput.selectionEnd;
    const val = designerInput.value;

    designerInput.value = val.substring(0, start) + text + val.substring(end);

    // Set cursor position after inserted text
    const newPos = start + text.length;
    designerInput.setSelectionRange(newPos, newPos);
    designerInput.focus();

    // Trigger preview update
    updateDesignerPreview();
}

/**
 * Advanced Line Transformation
 * Applies a template specifically to the selected lines in the input field.
 */
function applyCustomVibeToSelection(template) {
    const start = designerInput.selectionStart;
    const end = designerInput.selectionEnd;
    const val = designerInput.value;
    const selection = val.substring(start, end);

    if (!selection.trim()) {
        // No selection: just insert template as a ghost example
        insertAtCursor(template);
        return;
    }

    // Process selection line-by-line
    const lines = selection.split('\n');
    const transformed = lines.map(line => {
        if (!line.trim()) return line;

        const item = parseTipLine(line);
        if (!item) return line;

        // Use currently active theme icon if {icon} is present in template
        const theme = VTE_THEMES[currentDesignerVibe] || { bullet: '' };

        return template
            .replace(/{label}/g, item.label)
            .replace(/{price}/g, item.price)
            .replace(/{icon}/g, theme.bullet || '');
    }).join('\n');

    designerInput.value = val.substring(0, start) + transformed + val.substring(end);

    // Maintain selection on the transformed block
    designerInput.setSelectionRange(start, start + transformed.length);
    designerInput.focus();

    updateDesignerPreview();
}

initStyleAssets();
