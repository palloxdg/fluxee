# Fansly Tip Menu Bot v4.6 by Pallox - Tip Goal Sync Edition

The ultimate stream management tool. This version (v4.6) introduces **3-Slot Tip Goal Sync**, **Active Slot Highlighting**, and a **Modernized UI** with gradients and toggle switches.

## 🚀 NEW in v4.6
- **3-Slot Tip Goal Sync:** Support for Fansly's 3-slot system. Sync goals to Top, Middle, or Bottom slots.
- **Logical Mapping:** Slot 1 = Bottom (Easiest), Slot 2 = Middle, Slot 3 = Top (Hardest).
- **Active Slot Highlighting:** Slot buttons (1/2/3) glow in **Cyan** when active on Fansly.
- **Modernized UI:** Replaced checkboxes with **Toggle Switches** and updated buttons with **Linear Gradients** and softer 8px corners.

## 🛠️ Installation
1.  **Open Chrome Extensions**: Go to `chrome://extensions/`
2.  **Developer Mode**: Toggle the switch in the top right.
3.  **Load Bot**: Click **"Load Unpacked"** and select the `v4.6_Tip_Goals` folder.
4.  **📌 PIN FOR QUICK ACCESS**:
    *   Click the **Puzzle Piece icon** (🧩) in your Chrome toolbar.
    *   Find **Fansly Tip Menu Bot v4.6 by Pallox** and click the **Pin icon** (📌).
5.  **Open the Side Panel**: Click the pinned Extension Icon in your toolbar.

## 🔐 One-Time Permission Setup
1. Go to **fansly.com**.
2. Right-click the Bot's icon in your toolbar.
3. Select **"This can read and change site data"**.
4. Ensure **"On fansly.com"** is selected.
*This ensures the bot activates automatically every time you load your stream!*

> [!IMPORTANT]
> REFRESH THE FANSLY PAGE AFTER INSTALLING OR UPDATING THE BOT.

## 📈 Tip Analytics & Goal Sync
Click **"📈 Tip Analytics"** to view your dashboard.
- **Goal Sync:** Click 1, 2, or 3 next to a goal to sync it to that slot on Fansly.
- **Highlighting:** A **Cyan** fill indicates the goal is currently live in that slot.
- **Sorting:** Click "Item", "Count", or "Total" headers to sort.
- **Net Revenue:** Automatically calculates your take-home pay after Fansly's 20% fee.
- **Peak Hours Chart:** Visualize your busiest times with an interactive bar chart.

## 📝 How to Add Custom Commands
1. Open the Side Panel.
2. In the **Auto-Responder** section, click the **⚙️ Add/Edit** button.
3. Enter a short **Trigger Name** (the `!` is added automatically).
4. Enter the **Bot Response** and click **💾 Save Command**.

## 💾 How to Backup & Restore Data
1. Open the Side Panel and scroll to the bottom.
2. Click **💾 Export Backup** to save `Fansly_Tip_Menu_Bot_Backup_YYYYMMDD.txt`.
3. **To Restore:** Click **📂 Import Backup** and select your `.txt` file.

## 📜 Changes Archive

### Version 4.5
- **Multi-Language Support (EN/PL):** Switch languages instantly via header flags.
- **Goal Smart-Reset:** Reset goal progress without wiping overall revenue history.
- **Symmetrical UI:** Improved header balance for a more premium look.

### Version 4.4
- **Advanced Tip Analytics:** 24h, 7d, 30d, and All History tracking with multi-column sorting.
- **Opportunity Tracking:** View untipped items from all your saved menus.
- **Custom Tip Support:** Automatically records tips not found in your standard menu.
- **Data Backup & Restore:** Export/Import your entire setup to a file.

---
*Remember to refresh your fansly.com page after installing or updating the bot!*
