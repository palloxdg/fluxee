# 🤖 Fansly Bot v4.6: AI Assistant Roadmap

## Goal
To implement a "Human-in-the-Loop" AI Co-Pilot that assists streamers with DM engagement, increasing revenue and fan retention while maintaining 100% account safety.

---

## 🛠️ Core AI Concept: The "Co-Pilot"
Unlike an auto-responder, the AI Assistant provides **suggestions** rather than taking independent actions.

### The Workflow:
1.  **Context Scraping**: The bot reads the active DM thread (last 3-5 messages).
2.  **Persona Processing**: The context is sent to an LLM (e.g., GPT-4o) along with your "Persona Engine" configuration.
3.  **The 3-Reply Offer**: The bot generates 3 distinct reply options:
    *   **Option 1: Conversational** (Friendly engagement)
    *   **Option 2: Upsell** (Directing to Menu/Locked Content)
    *   **Option 3: Intimate/Flirty** (High-energy for top fans)
4.  **Human Override**: The streamer clicks a reply, it populates the Fansly message box, and the streamer can **edit** it before hitting "Send."

---

## 🧠 The Persona Engine (Training)
We will "train" the AI through a structured 4-layer configuration:

### Layer A: Identity (System Prompt)
*   Define your "Voice" (Tone, favorite emojis, personality traits).
*   Example: *"You are playful, slightly bratty, but always professional."*

### Layer B: Knowledge Base (Static Data)
*   **Prices**: List of menu items and custom request costs.
*   **Schedule**: Live stream days and upload times.
*   **Boundaries**: Hard limits on what you will/won't do.

### Layer C: Style Guide (Few-Shot Examples)
*   A library of 5-10 "Ideal Interactions" (Fan Message -> Your Perfect Answer).

### Layer D: Context Loop (Dynamic Data)
*   Feeding the fan's spending history and recent tip items into the AI for personalized replies.

---

## 🛡️ Safety & Security
*   **No Automated Sending**: All AI-generated text must be approved by the human streamer.
*   **Local Processing**: The logic resides in the extension, keeping the session within the authenticated browser environment.
*   **API Privacy**: Users provide their own OpenAI/Gemini API keys to maintain control over costs and data privacy.

---

## 🌎 Internationalization (i18n)
To make the bot accessible and professional for a global audience, v4.6 will move away from hardcoded English strings.

### The Strategy:
- **Centralized Dictionary**: Move all UI text (buttons, labels, alerts) into a `translations.js` mapping.
- **Instant Toggle**: Implement a 🇬🇧/🇵🇱 switcher in the sidepanel that updates the UI live without reloading.
- **Persistence**: Save the user's language preference to local storage.
- **Scaleable Design**: UI layouts will be tested for "text expansion" (some Polish words are significantly longer than English).

---

## 📅 Next Steps
1.  [ ] Prototype DM scraper for active thread context.
2.  [ ] Design the "AI Sandbox" UI in the sidepanel.
3.  [ ] Map all existing UI strings for **Internationalization**.
4.  [ ] Implement initial "Persona" configuration fields.
5.  [ ] Test "3-Reply" generation with mock DM data.
