const menuSelect = document.getElementById('menuSelect');
const menuName = document.getElementById('menuName');
const menuContent = document.getElementById('menuContent');
const saveMenuBtn = document.getElementById('saveMenuBtn');
const deleteMenuBtn = document.getElementById('deleteMenuBtn');
const newMenuBtn = document.getElementById('newMenuBtn');
const autoPostValue = document.getElementById('autoPostValue');
const autoPostUnit = document.getElementById('autoPostUnit');
const enableAutoMod = document.getElementById('enableAutoMod');
const enableResponder = document.getElementById('enableResponder');
const enableAutoThanks = document.getElementById('enableAutoThanks');
const autoThankMessage = document.getElementById('autoThankMessage');
const cooldownMinutes = document.getElementById('cooldownMinutes');
const toggleBotBtn     = document.getElementById('toggleBotBtn');
const sendSelectionBtn = document.getElementById('sendSelectionBtn');
const testPostBtn = document.getElementById('testPostBtn');
const statusText = document.getElementById('statusText');

// Notification Elements
const toastContainer = document.getElementById('toast-container');
const confirmModalOverlay = document.getElementById('confirm-modal-overlay');
const confirmModalMessage = document.getElementById('confirm-modal-message');
const confirmModalYes = document.getElementById('confirm-modal-yes');
const confirmModalNo = document.getElementById('confirm-modal-no');

// Tipper List UI
const tipperListDisplay = document.getElementById('tipperListDisplay');
const tipperCountDisplay = document.getElementById('tipperCount');
const copyTippersBtn = document.getElementById('copyTippersBtn');
const clearTippersBtn = document.getElementById('clearTippersBtn');

// Backup & Restore UI
const exportBtn = document.getElementById('exportBtn');
const importBtn = document.getElementById('importBtn');
const importFile = document.getElementById('importFile');

// Navigation & Tabs
const mainHeader = document.getElementById('mainHeader');
const easterEggMessage = document.getElementById('easterEggMessage');
const mainView = document.getElementById('mainView');
const commandsView = document.getElementById('commandsView');
const openCommandsBtn = document.getElementById('openCommandsBtn');
const backToMainBtn = document.getElementById('backToMainBtn');

const openAnalyticsTabBtn = document.getElementById('openAnalyticsTabBtn');
const openBackupBtn = document.getElementById('openBackupBtn');
const backupView = document.getElementById('backupView');
const backToMainFromBackupBtn = document.getElementById('backToMainFromBackupBtn');
const backArrowCommands = document.getElementById('backArrowCommands');
const backArrowBackup = document.getElementById('backArrowBackup');

// Designer View UI
const openDesignerViewBtn = document.getElementById('openDesignerViewBtn');
const openAutoModBtn = document.getElementById('openAutoModBtn');
const openAutoModTabBtn = document.getElementById('openAutoModTabBtn');

const commandsList = document.getElementById('commandsList');
const saveCommandBtn = document.getElementById('saveCommandBtn');
const commandTrigger = document.getElementById('commandTrigger');
const commandResponse = document.getElementById('commandResponse');

let menus = {};
let currentMenuId = null;
let isRunning = false;
let tipperList = [];
let customCommands = [];
let currentLang = 'en';
function applyLanguage(lang) {
    currentLang = lang;
    const trans = uiTranslations[lang];
    if (!trans) return;

    // Update active flag state
    document.querySelectorAll('.lang-flag-mini').forEach(flag => {
        flag.classList.toggle('active', flag.dataset.lang === lang);
    });

    // Multi-Language Text Content
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (trans[key]) {
            if (key === 'captured') {
                const count = el.dataset.i18nCount || 0;
                el.innerText = trans[key].replace('{count}', count);
            } else {
                el.innerText = trans[key];
            }
        }
    });

    // Multi-Language Placeholders
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.dataset.i18nPlaceholder;
        if (trans[key]) el.placeholder = trans[key];
    });

    // Multi-Language Titles (tooltips)
    document.querySelectorAll('[data-i18n-title]').forEach(el => {
        const key = el.dataset.i18nTitle;
        if (trans[key]) el.title = trans[key];
    });

    updateToggleBtn();
    updateTipperDisplay();
    renderCommandsList();
}

function generateId() {
    return Math.random().toString(36).substr(2, 9);
}

// --- Custom Notification Helpers ---
function showToast(message, duration = 3000) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>${message}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

function showConfirm(message, onConfirm) {
    confirmModalMessage.textContent = message;
    confirmModalOverlay.style.display = 'flex';

    const cleanup = () => {
        confirmModalOverlay.style.display = 'none';
        confirmModalYes.onclick = null;
        confirmModalNo.onclick = null;
    };

    confirmModalYes.onclick = () => {
        cleanup();
        if (onConfirm) onConfirm();
    };

    confirmModalNo.onclick = () => {
        cleanup();
    };
}

function loadState() {
    const storageArea = chrome.storage ? chrome.storage.local : {
        get: (keys, cb) => {
            const res = {};
            keys.forEach(k => {
                const val = localStorage.getItem(k);
                try { res[k] = JSON.parse(val); } catch (e) { res[k] = val; }
            });
            cb(res);
        },
        set: (data, cb) => {
            for (const k in data) {
                localStorage.setItem(k, typeof data[k] === 'object' ? JSON.stringify(data[k]) : data[k]);
            }
            if (cb) cb();
        }
    };

    storageArea.get(['menus', 'currentMenuId', 'autoPostValue', 'autoPostUnit', 'enableResponder', 'enableAutoThanks', 'autoThankMessage', 'cooldownMinutes', 'isRunning', 'tipperList', 'customCommands', 'currentLang', 'enableAutoMod'], (result) => {
        menus = result.menus || {};
        currentMenuId = result.currentMenuId || null;
        if (result.autoPostValue) autoPostValue.value = result.autoPostValue;
        if (result.autoPostUnit) autoPostUnit.value = result.autoPostUnit;
        enableResponder.checked = !!result.enableResponder;
        enableAutoThanks.checked = !!result.enableAutoThanks;
        if (result.autoThankMessage) autoThankMessage.value = result.autoThankMessage;
        if (result.cooldownMinutes) cooldownMinutes.value = result.cooldownMinutes;
        isRunning = !!result.isRunning;
        tipperList = Array.isArray(result.tipperList) ? result.tipperList : [];
        customCommands = Array.isArray(result.customCommands) ? result.customCommands : [];
        currentLang = result.currentLang || 'en';
        enableAutoMod.checked = !!result.enableAutoMod;

        if (Object.keys(menus).length === 0) {
            const id = generateId();
            menus[id] = { name: "Default Menu", content: "" };
            currentMenuId = id;
            saveState();
        }

        updateMenuSelect();
        updateForms();
        updateInputStates();
        updateToggleBtn();
        updateTipperDisplay();
        renderCommandsList();
        applyLanguage(currentLang);
    });
}

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, namespace) => {
        if (namespace === 'local') {
            if (changes.menus || changes.currentMenuId) {
                loadState();
            }
            // 🎆 Easter Egg: fireworks every $500 in tips
            if (changes.tipAnalytics) {
                const tips = changes.tipAnalytics.newValue || [];
                const total = tips.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
                const milestone = 500;
                const prevTotal = changes.tipAnalytics.oldValue
                    ? changes.tipAnalytics.oldValue.reduce((sum, t) => sum + (Number(t.amount) || 0), 0)
                    : 0;
                // Fire when we cross a $500 boundary
                if (Math.floor(total / milestone) > Math.floor(prevTotal / milestone)) {
                    triggerFireworks();
                }
            }
        }
    });
}

function saveState() {
    const data = {
        menus: menus,
        currentMenuId: currentMenuId,
        autoPostValue: parseInt(autoPostValue.value) || 10,
        autoPostUnit: autoPostUnit.value || 'minutes',
        enableResponder: enableResponder.checked,
        enableAutoThanks: enableAutoThanks.checked,
        autoThankMessage: autoThankMessage.value || "✨ {user} just tipped for: {item}! ✨",
        cooldownMinutes: parseInt(cooldownMinutes.value) || 10,
        isRunning: isRunning,
        tipperList: tipperList,
        customCommands: customCommands,
        currentLang: currentLang,
        enableAutoMod: enableAutoMod.checked
    };

    if (chrome.storage && chrome.storage.local) {
        chrome.storage.local.set(data);
    } else {
        // Fallback for local testing
        for (const k in data) {
            localStorage.setItem(k, typeof data[k] === 'object' ? JSON.stringify(data[k]) : data[k]);
        }
    }
}

function updateTipperDisplay() {
    const trans = uiTranslations[currentLang];
    if (tipperList.length === 0) {
        tipperListDisplay.textContent = trans.noTippers;
        tipperCountDisplay.textContent = trans.captured.replace('{count}', 0);
        tipperCountDisplay.dataset.i18nCount = 0;
    } else {
        tipperListDisplay.textContent = tipperList.join(', ');
        tipperCountDisplay.textContent = trans.captured.replace('{count}', tipperList.length);
        tipperCountDisplay.dataset.i18nCount = tipperList.length;
    }
}

function updateMenuSelect() {
    menuSelect.innerHTML = '';
    for (const id in menus) {
        const option = document.createElement('option');
        option.value = id;
        option.textContent = menus[id].name;
        if (id === currentMenuId) option.selected = true;
        menuSelect.appendChild(option);
    }
}

function updateForms() {
    if (currentMenuId && menus[currentMenuId]) {
        menuName.value = menus[currentMenuId].name;
        menuContent.value = menus[currentMenuId].content;
    } else {
        menuName.value = '';
        menuContent.value = '';
    }
    setTimeout(resizeUI, 0);
}

function updateToggleBtn() {
    const trans = uiTranslations[currentLang];
    const autoModOn = enableAutoMod.checked;

    if (isRunning) {
        toggleBotBtn.textContent = trans.stopBot;
        toggleBotBtn.className = 'btn stop';
        statusText.textContent = autoModOn ? trans.statusRunningOn : trans.statusRunningOff;
        statusText.className = 'status running';
        disableInputs(true);
    } else {
        toggleBotBtn.textContent = trans.startBot;
        toggleBotBtn.className = 'btn start';
        statusText.textContent = autoModOn ? trans.statusStoppedOn : trans.statusStoppedOff;
        statusText.className = 'status stopped';
        disableInputs(false);
    }
    chrome.action.setIcon({ path: isRunning ? "icon_red.png" : "icon_grey.png" });
    updateSendSelectionBtn();
}

function disableInputs(disabled) {
    menuSelect.disabled = disabled;
    menuName.disabled = disabled;
    menuContent.readOnly = disabled;
    menuContent.classList.toggle('bot-running-readonly', disabled);
    autoPostValue.disabled = disabled;
    autoPostUnit.disabled = disabled;
    enableResponder.disabled = disabled;
    enableAutoThanks.disabled = disabled;
    cooldownMinutes.disabled = disabled || !enableResponder.checked;
    autoThankMessage.disabled = disabled || !enableAutoThanks.checked;
    if (openAutoModBtn) openAutoModBtn.disabled = disabled;
}

function updateInputStates() {
    cooldownMinutes.disabled = !enableResponder.checked || isRunning;
    autoThankMessage.disabled = !enableAutoThanks.checked || isRunning;
    openCommandsBtn.disabled = isRunning;
    if (openAutoModBtn) openAutoModBtn.disabled = isRunning;
}

// Easter Egg Logic
let clickCount = 0;
let clickTimer = null;

mainHeader.addEventListener('click', () => {
    // If already visible, hide it on the next single click
    if (easterEggMessage.classList.contains('easter-egg-visible')) {
        easterEggMessage.classList.remove('easter-egg-visible');
        clickCount = 0;
        return;
    }

    clickCount++;

    if (clickCount >= 5) {
        easterEggMessage.classList.add('easter-egg-visible');
        clickCount = 0; // Reset
    }

    // Reset the counter if they stop clicking for 1 second
    clearTimeout(clickTimer);
    clickTimer = setTimeout(() => {
        clickCount = 0;
    }, 1000);
});

// OSCAR Easter Egg Logic
let oscarKeys = [];
let oscarActive = false;

document.addEventListener('keydown', (e) => {
    // Ignore if typing in an input field or textarea
    const tag = e.target.tagName.toLowerCase();
    if (tag === 'input' || tag === 'textarea') return;

    oscarKeys.push(e.key.toLowerCase());
    if (oscarKeys.length > 5) oscarKeys.shift();

    if (oscarKeys.join('') === 'oscar') {
        oscarKeys = []; // reset
        triggerOscar();
    }
});

function triggerOscar() {
    if (oscarActive) return;
    oscarActive = true;

    // Create the cat if it doesn't exist
    let oscar = document.getElementById('oscar-cat');
    if (!oscar) {
        oscar = document.createElement('div');
        oscar.id = 'oscar-cat';
        document.body.appendChild(oscar);
    }

    // Reset styles & position
    oscar.style.display = 'block';

    let frame = 0;
    const totalFrames = 24; // User requested 0 to 23
    const columns = 5;
    const frameSize = 256; // High-res frame size

    let isMoving = true;
    let positionRight = -300; // Start off-screen right (larger sprite)

    // Calculate center based on actual panel width
    const panelWidth = document.body.clientWidth || 320;
    const endRight = panelWidth + 300;

    const animInterval = setInterval(() => {
        // Frame calculation - only step through when moving
        if (isMoving) {
            const col = frame % columns;
            const row = Math.floor(frame / columns);
            oscar.style.backgroundPosition = `-${col * frameSize}px -${row * frameSize}px`;

            frame = (frame + 1) % totalFrames;

            positionRight += 5; // Increased slide speed (from 3 to 5)
            oscar.style.right = positionRight + 'px';

            // Walking out left: Reached off-screen
            if (positionRight > endRight) {
                clearInterval(animInterval);
                oscar.style.display = 'none';
                oscarActive = false;
            }
        }
    }, 40); // Slightly faster interval for smoother 24fps look
}

// 🎆 FIREWORKS Easter Egg — triggers when tips cross a $500 milestone
function triggerFireworks() {
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:9999;';
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    const particles = [];
    const colors = ['#ff4444', '#ffaa00', '#ffff00', '#44ff88', '#00e5ff', '#cc44ff', '#ff88cc'];

    // Create burst from 3 random spots
    for (let b = 0; b < 3; b++) {
        const cx = canvas.width * (0.25 + Math.random() * 0.5);
        const cy = canvas.height * (0.2 + Math.random() * 0.4);
        for (let i = 0; i < 60; i++) {
            const angle = (Math.PI * 2 / 60) * i;
            const speed = 2 + Math.random() * 5;
            particles.push({
                x: cx, y: cy,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                alpha: 1,
                color: colors[Math.floor(Math.random() * colors.length)],
                radius: 2 + Math.random() * 2
            });
        }
    }

    let frame = 0;
    const maxFrames = 90;

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.12; // gravity
            p.alpha -= 1 / maxFrames;
            ctx.globalAlpha = Math.max(p.alpha, 0);
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fill();
        });
        frame++;
        if (frame < maxFrames) {
            requestAnimationFrame(draw);
        } else {
            canvas.remove();
        }
    }

    requestAnimationFrame(draw);
    showToast('🎆 $500 milestone reached! Amazing!');
}

// Navigation Events
openCommandsBtn.addEventListener('click', () => {
    mainView.style.display = 'none';
    commandsView.style.display = 'block';
});

backToMainBtn.addEventListener('click', () => {
    commandsView.style.display = 'none';
    mainView.style.display = 'flex';
});

openAnalyticsTabBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: 'analytics.html' });
});

openBackupBtn.addEventListener('click', () => {
    mainView.style.display = 'none';
    backupView.style.display = 'flex';
});

backToMainFromBackupBtn.addEventListener('click', () => {
    backupView.style.display = 'none';
    mainView.style.display = 'flex';
});

// Back Arrow Navigation
backArrowCommands.addEventListener('click', () => {
    commandsView.style.display = 'none';
    mainView.style.display = 'flex';
});

backArrowBackup.addEventListener('click', () => {
    backupView.style.display = 'none';
    mainView.style.display = 'flex';
});

// Designer Navigation
openDesignerViewBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: 'designer.html' });
});

if (openAutoModBtn) {
    openAutoModBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'automod.html' });
    });
}



// Custom Commands Logic
function renderCommandsList() {
    commandsList.innerHTML = '';
    if (customCommands.length === 0) {
        commandsList.innerHTML = `<div style="color: #aaa; font-size: 13px;">${uiTranslations[currentLang].noCommands}</div>`;
        return;
    }

    customCommands.forEach((cmd, index) => {
        const item = document.createElement('div');
        item.className = 'command-item';

        const info = document.createElement('div');
        info.className = 'command-item-info';

        const triggerDiv = document.createElement('div');
        triggerDiv.className = 'command-item-trigger';
        triggerDiv.textContent = `!${cmd.trigger}`;

        const responseDiv = document.createElement('div');
        responseDiv.className = 'command-item-response';
        responseDiv.textContent = cmd.response;

        info.appendChild(triggerDiv);
        info.appendChild(responseDiv);

        const actions = document.createElement('div');
        actions.className = 'command-item-actions';

        const toggle = document.createElement('input');
        toggle.type = 'checkbox';
        toggle.className = 'command-toggle';
        toggle.checked = cmd.active;
        toggle.addEventListener('change', () => {
            customCommands[index].active = toggle.checked;
            saveState();
        });

        const editBtn = document.createElement('button');
        editBtn.className = 'edit-cmd-btn';
        editBtn.innerHTML = '✏️';
        editBtn.title = uiTranslations[currentLang].editCommand;
        editBtn.addEventListener('click', () => {
            commandTrigger.value = cmd.trigger;
            commandResponse.value = cmd.response;
            commandTrigger.focus();
        });

        const delBtn = document.createElement('button');
        delBtn.className = 'del-cmd-btn';
        delBtn.innerHTML = '🗑️';
        delBtn.title = uiTranslations[currentLang].deleteCommand;
        delBtn.addEventListener('click', () => {
            showConfirm(uiTranslations[currentLang].confirmDeleteMenu.replace('{name}', `!${cmd.trigger}`), () => {
                customCommands.splice(index, 1);
                saveState();
                renderCommandsList();
            });
        });

        actions.appendChild(toggle);
        actions.appendChild(editBtn);
        actions.appendChild(delBtn);

        item.appendChild(info);
        item.appendChild(actions);
        commandsList.appendChild(item);
    });
}

saveCommandBtn.addEventListener('click', () => {
    const trigger = commandTrigger.value.trim().toLowerCase().replace(/^!/, ''); // Ensure no leading !
    const response = commandResponse.value.trim();

    if (!trigger) {
        showToast(uiTranslations[currentLang].triggerName);
        return;
    }
    if (!response) {
        showToast(uiTranslations[currentLang].botResponse);
        return;
    }

    // Check for duplicates
    const existingIndex = customCommands.findIndex(cmd => cmd.trigger === trigger);
    if (existingIndex > -1) {
        showConfirm(uiTranslations[currentLang].confirmDeleteMenu.replace('{name}', `!${trigger}`), () => {
            customCommands[existingIndex].response = response;
            saveState();
            renderCommandsList();
            // Clear inputs
            commandTrigger.value = '';
            commandResponse.value = '';
        });
        return;
    } else {
        customCommands.push({ trigger: trigger, response: response, active: true });
    }

    saveState();
    renderCommandsList();

    // Clear inputs
    commandTrigger.value = '';
    commandResponse.value = '';
});

// Flag Click Listeners
document.querySelectorAll('.lang-flag-mini').forEach(flag => {
    flag.addEventListener('click', () => {
        applyLanguage(flag.dataset.lang);
        saveState();
    });
});

// Help Icons
document.querySelectorAll('.help-icon').forEach(icon => {
    icon.addEventListener('click', (e) => {
        e.stopPropagation(); // Prevent trigger header toggle if on mainHeader
        window.open('guide.html', '_blank');
    });
});

// Events
menuSelect.addEventListener('change', (e) => {
    currentMenuId = e.target.value;
    updateForms();
    saveState();
});

saveMenuBtn.addEventListener('click', () => {
    if (!currentMenuId) currentMenuId = generateId();
    const name = menuName.value.trim() || "Unnamed Menu";
    const content = menuContent.value;
    menus[currentMenuId] = { name, content };
    saveState();
    updateMenuSelect();
    showToast(uiTranslations[currentLang].saveSuccess);
});

newMenuBtn.addEventListener('click', () => {
    currentMenuId = generateId();
    menus[currentMenuId] = { name: "New Menu", content: "" };
    saveState();
    updateMenuSelect();
    updateForms();
});

function resizeUI() {
    if (!menuContent) return;

    // Temporarily set height to auto to get an accurate scrollHeight for the new content
    menuContent.style.height = 'auto';

    const scrollHeight = menuContent.scrollHeight;
    // Keep internal minimum of 120px and max of 400px
    const clampedHeight = Math.min(Math.max(scrollHeight, 120), 400);

    menuContent.style.height = clampedHeight + 'px';
    menuContent.style.overflowY = scrollHeight > 400 ? 'auto' : 'hidden';
}

menuContent.addEventListener('input', () => { saveState(); resizeUI(); });
autoPostValue.addEventListener('change', saveState);
autoPostUnit.addEventListener('change', saveState);
enableResponder.addEventListener('change', () => { saveState(); updateInputStates(); });
enableAutoThanks.addEventListener('change', () => { saveState(); updateInputStates(); });
autoThankMessage.addEventListener('input', saveState);
cooldownMinutes.addEventListener('change', saveState);
enableAutoMod.addEventListener('change', () => { saveState(); updateToggleBtn(); });

toggleBotBtn.addEventListener('click', () => {
    isRunning = !isRunning;
    saveState();
    updateToggleBtn();
    chrome.runtime.sendMessage({
        action: isRunning ? 'start' : 'stop',
        value: parseInt(autoPostValue.value) || 10,
        unit: autoPostUnit.value
    });
})

// ── Send Selection to Chat ────────────────────────────────────────────────────
function updateSendSelectionBtn() {
    if (!sendSelectionBtn) return;
    const hasSelection = menuContent &&
        menuContent.selectionStart !== menuContent.selectionEnd;
    sendSelectionBtn.disabled = !(isRunning && hasSelection);
}

if (menuContent) {
    menuContent.addEventListener('select',  updateSendSelectionBtn);
    menuContent.addEventListener('mouseup', updateSendSelectionBtn);
    menuContent.addEventListener('keyup',   updateSendSelectionBtn);
}

if (sendSelectionBtn) {
    sendSelectionBtn.addEventListener('click', () => {
        if (!menuContent || !isRunning) return;
        const selected = menuContent.value.substring(
            menuContent.selectionStart,
            menuContent.selectionEnd
        ).trim();
        if (!selected) return;
        chrome.runtime.sendMessage({ action: 'send_selection', text: selected });
        const orig = sendSelectionBtn.textContent;
        sendSelectionBtn.textContent = '✅';
        setTimeout(() => { sendSelectionBtn.textContent = orig; }, 1500);
    });
}
;

testPostBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'test_post' });
});

copyTippersBtn.addEventListener('click', () => {
    if (tipperList.length === 0) return;
    const text = tipperList.join(', ');
    navigator.clipboard.writeText(text).then(() => {
        const originalText = copyTippersBtn.textContent;
        copyTippersBtn.textContent = uiTranslations[currentLang].copied;
        setTimeout(() => copyTippersBtn.textContent = originalText, 1500);
    });
});

clearTippersBtn.addEventListener('click', () => {
    showConfirm(uiTranslations[currentLang].confirmClearTippers, () => {
        tipperList = [];
        saveState();
        updateTipperDisplay();
        chrome.runtime.sendMessage({ action: 'clear_tippers' });
    });
});

deleteMenuBtn.addEventListener('click', () => {
    if (currentMenuId && menus[currentMenuId]) {
        showConfirm(uiTranslations[currentLang].confirmDeleteMenu.replace('{name}', menus[currentMenuId].name), () => {
            delete menus[currentMenuId];
            currentMenuId = Object.keys(menus)[0] || null;
            saveState();
            updateMenuSelect();
            updateForms();
        });
    }
});

// Backup & Restore Logic
exportBtn.addEventListener('click', () => {
    chrome.storage.local.get(null, (allData) => {
        const backupData = { ...allData };
        delete backupData.isRunning;
        delete backupData.tipperList;
        const jsonString = JSON.stringify(backupData, null, 2);
        const blob = new Blob([jsonString], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const date = new Date();
        const filename = `Fansly_Bot_Backup_${date.toISOString().split('T')[0]}.txt`;
        chrome.downloads.download({
            url: url,
            filename: filename,
            saveAs: true
        }, () => {
            URL.revokeObjectURL(url);
        });
    });
});

importBtn.addEventListener('click', () => {
    importFile.click();
});

importFile.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const importedData = JSON.parse(event.target.result);
            chrome.storage.local.set(importedData, () => {
                showToast(uiTranslations[currentLang].importSuccess);
                loadState();
            });
        } catch (error) {
            showToast(uiTranslations[currentLang].importFail);
        }
    };
    reader.readAsText(file);
    e.target.value = '';
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'tipper_list_updated') {
        tipperList = request.list;
        updateTipperDisplay();
    } else if (request.action === 'chat_oscar') {
        // 🐱 Easter Egg: someone typed "oscar" in chat!
        triggerOscar();
    }
    sendResponse({});
});

document.addEventListener('DOMContentLoaded', loadState);
