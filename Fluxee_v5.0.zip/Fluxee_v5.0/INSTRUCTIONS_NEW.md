# Fansly Tip Menu Bot v4.4 by Pallox

This version (v4.4) adds **Advanced Tip Analytics**, **Opportunity Tracking**, and **Custom Tip Support**!

## 🚀 NEW in Version 4.4
- **Advanced Tip Analytics:** Detailed tracking of all tips with a global timeframe selector.
- **Untipped Items (Opportunities):** See which items in your menu haven't been tipped yet.
- **Custom Tip Support:** Amounts like $22 or $0.50 that aren't in your menu are still recorded accurately.
- **Data Backup & Restore:** Instantly save all of your Tip Menus, Custom Commands, and settings into a clean text file.
- **Universal Cooldown:** All commands share the same global cooldown timer to prevent spam.

## 🛠️ Step-by-Step Installation
1.  **Open Chrome Extensions**: Go to `chrome://extensions/`
2.  **Developer Mode**: Toggle the switch in the top right.
3.  **Load Bot**: Click **"Load Unpacked"** and select the `v4.4_Custom_Tips` folder.
4.  **📌 PIN FOR QUICK ACCESS**:
    *   Click the **Puzzle Piece icon** (🧩) in your Chrome toolbar.
    *   Find **Fansly Tip Menu Bot v4.4 by Pallox** and click the **Pin icon** (📌).
5.  **Open the Side Panel**: Click the pinned Extension Icon in your toolbar.

## 🔐 One-Time Permission Setup
1. Go to **fansly.com**.
2. Right-click the Bot's icon in your toolbar.
3. Select **"This can read and change site data"**.
4. Ensure **"On fansly.com"** is selected.
*This ensures the bot activates automatically every time you load your stream!*

> [!IMPORTANT]
> REFRESH THE FANSLY PAGE AFTER INSTALLING OR UPDATING THE BOT.

## 📈 Tip Analytics
- Access via the **📈 Tip Analytics** button at the bottom.
- Use the **Display Period** to filter by 24h, 7d, 30d, or All Time.
- Click **Item**, **Count**, or **Total** to sort the statistics.
- Check the **Untipped Items** box to see missed opportunities across **all** your saved menus!
- **Net Revenue:** Automatically shows your 80% take-home pay.
- **ATV & Peak Hours:** Track your average tip value and busiest hours (7PM-2AM).
- **Tip Goals:** Set custom goals and watch the progress bar fill up in real-time!
- **Smart Reset:** Clearing the 24h view preserves your historical data!

## 📝 How to Add Custom Commands
1. Open the Side Panel.
2. In the **Auto-Responder** section, click the **⚙️ Add/Edit** button. This will open the Custom Commands menu.
3. Enter a short Trigger Name in the top box (e.g., socials - the ! is added automatically).
4. Enter the Bot Response in the bottom box.
5. Click 💾 Save Command. The command will appear in your "Saved Commands" list where you can temporarily disable or permanently delete it.
6. Click ⬅️ Back to Main Menu to return.
Now every time someone enters the command in chat, the bot will post the corresponding response (respecting the Universal Cooldown)

## 💾 How to Backup & Restore Data
1. Open the Side Panel and scroll to the bottom.
2. Click 💾 Export Backup. Your browser will ask you where to save a file named Fansly_Tip_Menu_Bot_Backup_YYYYMMDD.txt (it defaults to your Downloads folder). 
3. To Restore: Click 📂 Import Backup and select that .txt file from your computer. The bot will instantly reload all of your saved menus and commands!

## 📋 Guest List
Tippers are tracked automatically. Click **"📋 Copy List"** to use their names for invitations, or **"🗑️ Reset List"** for a new session.

---
*Remember to refresh your fansly.com page after installing or updating the bot!*
