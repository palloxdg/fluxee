let lastPostTime = 0;
let lastGlobalMessageTime = 0;
const GLOBAL_MESSAGE_COOLDOWN = 200; // 0.2 seconds safety window
let tipperList = [];
let messageCounter = 0;
let tipAnalytics = [];
let messageQueue = [];
let isProcessingQueue = false;
let lastRateLimitTime = 0;
const RATE_LIMIT_COOLDOWN = 10 * 60 * 1000; // 10 minutes

// Queue depth cap — drop excess to prevent burst backlog
const MAX_QUEUE_DEPTH = 10;

// Global Emergency Rate Breaker
const EMERGENCY_WINDOW_MS  = 20000;
const EMERGENCY_MAX_MSGS   = 8;
const emergencyMsgTimestamps = [];

// Storage write debounce for tipAnalytics
let analyticsWriteTimer = null;
const ANALYTICS_DEBOUNCE_MS = 500;

function scheduleTipAnalyticsWrite() {
    if (analyticsWriteTimer) clearTimeout(analyticsWriteTimer);
    analyticsWriteTimer = setTimeout(() => {
        analyticsWriteTimer = null;
        const CAP = 5000;
        if (tipAnalytics.length > CAP) {
            tipAnalytics = tipAnalytics.slice(-CAP);
        }
        chrome.storage.local.set({ tipAnalytics }, () => {
            chrome.runtime.sendMessage({
                action: 'tip_analytics_updated',
                tipAnalytics
            }).catch(() => { });
        });
    }, ANALYTICS_DEBOUNCE_MS);
}

// Enable Side Panel on icon click
chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error(error));

// Initialize list from storage on load
chrome.storage.local.get(['tipperList', 'tipAnalytics'], (result) => {
    tipperList = result.tipperList || [];
    tipAnalytics = result.tipAnalytics || [];
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'start') {
        const value = request.value || 10;
        const unit = request.unit || 'minutes';

        chrome.alarms.clearAll(); // Clear previous and keepalive
        messageCounter = 0; // Reset counter on start
        setupKeepAlive();

        if (unit === 'minutes') {
            chrome.alarms.create('FluxeeAction', { periodInMinutes: value });
        }
        pollActiveGoals(); // Trigger immediate poll on start
    } else if (request.action === 'stop') {
        chrome.alarms.clearAll();
    } else if (request.action === 'chat_message_received') {
        handleChatMessage();
    } else if (request.action === 'test_post') {
        triggerPost(true);
    } else if (request.action === 'chat_command') {
        handleChatCommand(request.command);
    } else if (request.action === 'new_tipper') {
        handleNewTipper(request.username, request.amount, request.timestamp);
    } else if (request.action === 'clear_tippers') {
        tipperList = [];
        chrome.storage.local.set({ tipperList: [] });
    } else if (request.action === 'sync_goal_to_fansly') {
        handleSyncGoalToFansly(request.goal, sendResponse);
        return true;
    } else if (request.action === 'ensure_chatroom_id') {
        // Now handled by content script natively for better cookie support
        // This remains for legacy sidepanel calls if any
        if (request.username) handleEnsureChatRoomId(request.username);
    } else if (request.action === 'identity_resolved') {
        console.log(`[Fluxee] Background received ChatRoomId from content: ${request.chatRoomId} (${request.streamerUsername})`);
        chrome.storage.local.set({
            chatRoomId: request.chatRoomId,
            streamerUsername: request.streamerUsername
        });
        pollActiveGoals();
    } else if (request.action === 'identity_failed') {
        console.error(`[FanslyBot] Content script failed to resolve identity: ${request.error}`);
    } else if (request.action === 'perform_sync_in_background') {
        handleBackgroundSync(request.goal, request.slotIndex, request.session, sendResponse);
        return true; // async
    } else if (request.action === 'tip_analytics_updated') {
        chrome.runtime.sendMessage(request).catch(() => { });
    } else if (request.action === 'post_moderation_warning') {
        enqueueMessage(request.message);
    } else if (request.action === 'send_selection') {
        if (request.text) enqueueMessage(request.text);
    }
});

function enqueueMessage(content) {
    if (!content) return;
    if (messageQueue.length >= MAX_QUEUE_DEPTH) {
        console.warn(`[FanslyBot] Queue full (${MAX_QUEUE_DEPTH}) — dropping message.`);
        return;
    }
    messageQueue.push(content);
    if (!isProcessingQueue) {
        // Stagger first message — never fire immediately
        const entryDelay = Math.floor(Math.random() * (3000 - 1000 + 1)) + 1000;
        isProcessingQueue = true;
        setTimeout(processQueue, entryDelay);
    }
}

function processQueue() {
    if (messageQueue.length === 0) {
        isProcessingQueue = false;
        return;
    }

    isProcessingQueue = true;
    const nextMessage = messageQueue.shift();
    sendToTabs(nextMessage);

    // Randomized delay between 2.5s and 5.5s for natural flow
    const delay = Math.floor(Math.random() * (5500 - 2500 + 1)) + 2500;
    setTimeout(processQueue, delay);
}

// Returns a Promise<{success, data|error}> so it can be awaited by both the
// message handler and the auto-queue trigger in pollActiveGoals.
async function handleBackgroundSync(goalData, session) {
    const chatRoomId = session.chatRoomId;
    const baseHeaders = {
        'Content-Type': 'application/json',
        'X-Fansly-CSRF-Token': session.csrf || '',
        'Origin': 'https://fansly.com',
        'Referer': 'https://fansly.com/creator/streaming'
    };
    if (session.token) baseHeaders['Authorization'] = session.token;

    console.log(`[Fluxee] [BackgroundSync] Posting goal "${goalData.label}" to ChatRoom: ${chatRoomId}`);

    try {
        const payload = {
            chatRoomId: chatRoomId,
            label: goalData.label,
            description: goalData.description || "",
            goalAmount: goalData.goalAmount,
            type: 0
        };

        const postUrls = [
            'https://apiv3.fansly.com/api/v1/chatroom/goal?ngsw-bypass=true',
            'https://apiv3.fansly.com/api/v1/chatroom/goals?ngsw-bypass=true'
        ];

        let lastErr = "All endpoints failed";
        for (const url of postUrls) {
            const postRes = await fetch(url, {
                method: 'POST',
                headers: baseHeaders,
                body: JSON.stringify(payload),
                credentials: 'include'
            });

            if (postRes.ok) {
                const data = await postRes.json();
                console.log(`[FanslyBot] [BackgroundSync] Sync SUCCESS: ${url}`);
                await chrome.storage.local.set({ lastSyncResult: { success: true, time: Date.now() } });
                return { success: true, data };
            } else {
                lastErr = `Status ${postRes.status}: ${await postRes.text()}`;
                console.warn(`[FanslyBot] [BackgroundSync] POST failed on ${url}: ${lastErr}`);
            }
        }
        throw new Error(lastErr);
    } catch (err) {
        console.error('[FanslyBot] [BackgroundSync] Error:', err);
        await chrome.storage.local.set({ lastSyncResult: { success: false, error: err.message, time: Date.now() } });
        return { success: false, error: err.message };
    }
}

chrome.storage.local.get(['isRunning'], (result) => {
    chrome.action.setIcon({ path: result.isRunning ? "icon_red.png" : "icon_grey.png" });
    if (result.isRunning) setupKeepAlive();
});

function setupKeepAlive() {
    chrome.alarms.create('FluxeeKeepAlive', { periodInMinutes: 1 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
    // Add "Jitter" (random 3-12 second delay) to mimic human randomness
    const jitter = Math.floor(Math.random() * (12000 - 3000 + 1)) + 3000;

    if (alarm.name === 'FluxeeKeepAlive') {
        setTimeout(() => {
            pollActiveGoals();
        }, jitter);
        return;
    }
    if (alarm.name === 'FluxeeAction') {
        setTimeout(() => {
            triggerPost();
            pollActiveGoals();
        }, jitter);
    }
});

let lastProcessedTip = { username: null, amount: null, time: 0 };

function handleNewTipper(username, amount, customTimestamp) {
    if (!username) return;
    username = username.trim();

    // Duplicate/Bypass Guard: 2-second window for identical tip events (matches burst guard)
    const now = Date.now();
    if (username === lastProcessedTip.username && amount === lastProcessedTip.amount && (now - lastProcessedTip.time < 2000)) {
        console.log(`[FanslyBot] Duplicate tip detected for ${username}, skipping.`);
        return;
    }
    lastProcessedTip = { username, amount, time: now };

    console.log(`[FanslyBot] New tipper detected: ${username}, amount: ${amount}`);

    // 1. Logic for Guest List — update in-memory immediately to avoid race condition
    if (!tipperList.includes(username)) {
        tipperList.push(username);
        chrome.storage.local.set({ tipperList }, () => {
            chrome.runtime.sendMessage({
                action: 'tipper_list_updated',
                list: tipperList
            }).catch(() => { });
        });
    }

    // 2. Logic for Tip Analytics and Auto-Thank
    if (amount) {
        chrome.storage.local.get(['enableAutoThanks', 'autoThankMessage', 'menus', 'currentMenuId', 'streamerUsername'], (result) => {
            // Self-Thank / Test Tip Guard: Covered by comparing with streamer's own username
            if (result.streamerUsername && username.toLowerCase() === result.streamerUsername.toLowerCase()) {
                console.log(`[FanslyBot] Self-tip or Lovense test detected for ${username}. Skipping thank/analytics.`);
                return;
            }

            const currentMenuId = result.currentMenuId;
            let menuContent = result.menus?.[currentMenuId]?.content;

            // Fallback: If no ID but there's a menu, try the first one
            if (!menuContent && result.menus) {
                const keys = Object.keys(result.menus);
                if (keys.length > 0) {
                    menuContent = result.menus[keys[0]].content;
                }
            }

            let matchedItem = null;
            if (menuContent) {
                matchedItem = matchAmountToMenu(amount, menuContent);
            }

            if (!matchedItem) {
                console.log(`[FanslyBot] Result: No menu match for $${amount}. Recording as Custom Tip.`);
                matchedItem = "Other / Custom Tip";
            } else {
                console.log(`[FanslyBot] Result: Match successful: ${matchedItem}`);
            }

            // 2a. Analytics — push to in-memory first to avoid stale-read race
            tipAnalytics.push({
                timestamp: customTimestamp || Date.now(),
                item: matchedItem,
                amount: amount,
                username: username
            });
            scheduleTipAnalyticsWrite();

            // 2b. Auto-thank logic
            if (result.enableAutoThanks) {
                const template = result.autoThankMessage || "✨ {user} just tipped for: {item}! ✨";
                const thankMessage = template.replace('{user}', username).replace('{item}', matchedItem);
                enqueueMessage(thankMessage);
            }
        });
    }
}

function matchAmountToMenu(amount, menuContent) {
    const lines = menuContent.split(/\r?\n/);
    for (const line of lines) {
        const trimmedLine = line.trim();
        let amountIdx = -1;
        let searchIndex = 0;

        // Find the index of the amount, making sure it isn't part of a larger number
        while (true) {
            let foundIdx = trimmedLine.indexOf(amount, searchIndex);
            if (foundIdx === -1) break;

            const nextChar = trimmedLine[foundIdx + amount.length];
            const prevChar = foundIdx > 0 ? trimmedLine[foundIdx - 1] : null;
            let isPrevNum = (prevChar && prevChar >= '0' && prevChar <= '9');
            let isNextNum = (nextChar && nextChar >= '0' && nextChar <= '9');

            if (!isPrevNum && !isNextNum) {
                amountIdx = foundIdx;
                break;
            }
            searchIndex = foundIdx + amount.length;
        }

        if (amountIdx === -1) continue;

        // Check the prefix before the number. 
        const prefix = trimmedLine.substring(0, amountIdx).toLowerCase();

        let alphabetCount = 0;
        for (let i = 0; i < prefix.length; i++) {
            const code = prefix.charCodeAt(i);
            if (code >= 97 && code <= 122) { // a-z
                alphabetCount++;
            }
        }

        // Subtract valid token words
        let tempPrefix = prefix;
        while (tempPrefix.includes("tokens")) { tempPrefix = tempPrefix.replace("tokens", ""); alphabetCount -= 6; }
        while (tempPrefix.includes("token")) { tempPrefix = tempPrefix.replace("token", ""); alphabetCount -= 5; }
        while (tempPrefix.includes("t")) { tempPrefix = tempPrefix.replace("t", ""); alphabetCount -= 1; }

        // If there are standard alphabet letters before the number, it's deep inside a description.
        if (alphabetCount > 0) continue;

        // We have a VALID line match!
        let rawItem = trimmedLine.substring(amountIdx + amount.length);

        // Clean up immediate suffix tokens
        if (rawItem.toLowerCase().startsWith('t ') || rawItem.toLowerCase().startsWith('tokens ')) {
            rawItem = rawItem.replace(/^(t|tokens)\s*/i, '');
        } else if (rawItem.toLowerCase() === 't' || rawItem.toLowerCase() === 'tokens') {
            rawItem = "";
        }

        const isRemovable = (char) => {
            if (!char) return false;
            const code = char.codePointAt(0);
            return (code === 0x20 || code === 0x2D || code === 0x2013 || code === 0x2014 || code === 0x3A || code === 0x24 || code >= 0x1F300 || code === 0x200D || code === 0xFE0F || code >= 0x2600);
        };

        while (rawItem.length > 0 && isRemovable(rawItem[0])) { rawItem = rawItem.substring(1); }
        while (rawItem.length > 0 && isRemovable(rawItem[rawItem.length - 1])) { rawItem = rawItem.substring(0, rawItem.length - 1); }

        return rawItem.trim() || null;
    }
    return null;
}

function handleChatMessage() {
    chrome.storage.local.get(['isRunning', 'autoPostUnit', 'autoPostValue'], (result) => {
        if (!result.isRunning || result.autoPostUnit !== 'messages') return;

        messageCounter++;
        const limit = result.autoPostValue || 10;

        if (messageCounter >= limit) {
            triggerPost();
            messageCounter = 0; // Reset after post
        }
    });
}

function handleChatCommand(command) {
    chrome.storage.local.get(['enableResponder', 'cooldownMinutes', 'customCommands'], (result) => {
        if (!result.enableResponder) return;

        const now = Date.now();
        const cooldownMs = (result.cooldownMinutes || 10) * 60 * 1000;
        const timeElapsed = now - lastPostTime;

        // Check generic cooldown logic for ALL commands
        if (timeElapsed < cooldownMs) {
            const minutesLeft = Math.ceil((cooldownMs - timeElapsed) / (60 * 1000));
            sendToTabs(`This command is on cooldown! Please wait another ${minutesLeft} minute(s) before trying again.`);
            return;
        }

        // 1. Hardcoded !menu logic
        if (command === '!menu') {
            triggerPost(true);
            return;
        }

        // 2. Custom Commands logic
        const customCommands = result.customCommands || [];
        // The command from content script will include the '!', e.g. "!socials"
        const cleanCommand = command.replace(/^!/, '').toLowerCase();

        const matchedCustom = customCommands.find(c => c.trigger.toLowerCase() === cleanCommand && c.active);
        if (matchedCustom) {
            enqueueMessage(matchedCustom.response);
            lastPostTime = Date.now(); // Put bot back on cooldown
        }
    });
}

function triggerPost(force = false) {
    chrome.storage.local.get(['menus', 'currentMenuId', 'isRunning'], (result) => {
        if (!result.isRunning && !force) return;
        const currentMenuId = result.currentMenuId;
        const menus = result.menus;

        if (currentMenuId && menus && menus[currentMenuId]) {
            enqueueMessage(menus[currentMenuId].content);
            lastPostTime = Date.now();
        }
    });
}

function handleSyncGoalToFansly(goalData, sendResponse) {
    chrome.tabs.query({ url: "*://*.fansly.com/*" }, (tabs) => {
        const creatorTab = tabs.find(t => t.url && t.url.includes('/creator/streaming'));
        const activeTab = tabs.find(t => t.active) || creatorTab || tabs[0];

        if (!activeTab) {
            sendResponse({ success: false, error: 'No Fansly tab found. Please keep Fansly open.' });
            return;
        }

        chrome.tabs.sendMessage(activeTab.id, { action: 'get_session_context' }, async (session) => {
            if (chrome.runtime.lastError || !session) {
                sendResponse({ success: false, error: 'Communication failed. Please refresh the Fansly tab.' });
            } else {
                const result = await handleBackgroundSync(goalData, session);
                sendResponse(result);
            }
        });
    });
}

// Auto-sync the next queued goal when a slot opens up.
// Called by pollActiveGoals when activeGoals.length < lastActiveGoals.length.
let autoSyncInProgress = false;

function autoSyncNextQueued() {
    if (autoSyncInProgress) return;
    autoSyncInProgress = true;
    chrome.tabs.query({ url: "*://*.fansly.com/creator/streaming*" }, (tabs) => {
        if (!tabs || tabs.length === 0) {
            console.log('[FanslyBot] [Queue] No creator tab open — skipping auto-sync this cycle.');
            autoSyncInProgress = false;
            return;
        }
        const creatorTab = tabs[0];

        chrome.storage.local.get(['goalQueue', 'goals'], (res) => {
            const queue = res.goalQueue || [];
            const goals = res.goals || [];
            if (queue.length === 0) return;

            const nextId = queue[0];
            const goal = goals.find(g => g.id === nextId);
            if (!goal) {
                chrome.storage.local.set({ goalQueue: queue.slice(1) });
                autoSyncInProgress = false;
                return;
            }

            const goalData = {
                label: goal.name,
                goalAmount: Math.round((goal.amount || 0) * 1000),
                description: goal.text || ''
            };

            chrome.tabs.sendMessage(creatorTab.id, { action: 'get_session_context' }, async (session) => {
                if (chrome.runtime.lastError || !session) {
                    console.warn('[FanslyBot] [Queue] Session unavailable — will retry next poll.');
                    autoSyncInProgress = false;
                    return;
                }
                console.log(`[FanslyBot] [Queue] Auto-syncing queued goal: "${goal.name}"`);
                let result;
                try {
                    result = await handleBackgroundSync(goalData, session);
                } finally {
                    autoSyncInProgress = false;
                }
                if (result.success) {
                    chrome.storage.local.set({ goalQueue: queue.slice(1) });
                    console.log(`[FanslyBot] [Queue] "${goal.name}" synced. Remaining queue: ${queue.length - 1}`);
                } else {
                    console.warn(`[FanslyBot] [Queue] Auto-sync failed: ${result.error}`);
                }
            });
        });
    });
}

let chatRoomIdPending = false;

function handleEnsureChatRoomId(username) {
    if (chatRoomIdPending) return;
    chatRoomIdPending = true;
    console.log(`[FanslyBot] Ensuring ChatRoomId for: ${username || 'Current User (fallback)'}`);

    let chatRoomId = null;

    // Use account/me if no username is provided (Creator Dashboard fallback)
    const accountUrl = username
        ? `https://apiv3.fansly.com/api/v1/account?usernames=${username}`
        : `https://apiv3.fansly.com/api/v1/account/me`;

    // Skip if we hit a rate limit recently
    if (Date.now() - lastRateLimitTime < RATE_LIMIT_COOLDOWN) {
        console.warn('[FanslyBot] Identity check suspended due to recent rate limit.');
        return;
    }

    fetch(accountUrl, { credentials: 'include' })
        .then(r => {
            if (r.status === 429) {
                lastRateLimitTime = Date.now();
                throw new Error('Rate limited (429)');
            }
            return r.json();
        })
        .then(data => {
            console.log('[FanslyBot] Account data lookup:', data);
            if (data.success && data.response) {
                // If it was /account?usernames=... it's an array, if /account/me it's an object (usually)
                const accountData = Array.isArray(data.response) ? data.response[0] : data.response;
                if (!accountData) throw new Error('Account data missing');

                const accountId = accountData.id;
                console.log(`[FanslyBot] Found AccountId: ${accountId}`);
                return fetch(`https://apiv3.fansly.com/api/v1/streaming/channel/${accountId}`, { credentials: 'include' });
            }
            throw new Error('Account lookup failed: ' + JSON.stringify(data));
        })
        .then(r => r.json())
        .then(data => {
            if (data.success && data.response) {
                chatRoomId = data.response.chatRoomId;
                if (chatRoomId) {
                    console.log(`[FanslyBot] Captured ChatRoomId: ${chatRoomId}`);
                    chrome.storage.local.set({ chatRoomId: chatRoomId });

                    // Trigger immediate poll since we just got the ID
                    pollActiveGoals();
                }
            }
            // Auto-Discovery of Active Goals
            return fetch(`https://apiv3.fansly.com/api/v1/chatrooms?ids=${chatRoomId}`);
        })
        .then(r => r.json())
        .then(data => {
            if (data.success && data.response && data.response[0]) {
                const activeGoals = data.response[0].activeGoals || [];
                const syncedGoals = {};

                // Reverse mapping to sync bot highlights
                // Slot 3 (Top) = Index 0
                // Slot 2 (Middle) = Index 1
                // Slot 1 (Bottom) = Index 2
                if (activeGoals[0]) syncedGoals.slot3 = activeGoals[0].label;
                if (activeGoals[1]) syncedGoals.slot2 = activeGoals[1].label;
                if (activeGoals[2]) syncedGoals.slot1 = activeGoals[2].label;

                chrome.storage.local.set({ syncedGoals: syncedGoals });
                console.log('[FanslyBot] Auto-discovered active goals:', syncedGoals);
            }
        })
        .then(() => { chatRoomIdPending = false; })
        .catch(err => {
            console.error('[FanslyBot] ChatRoomId/Goal discovery failed:', err);
            chatRoomIdPending = false;
        });
}

function pollActiveGoals() {
    chrome.storage.local.get(['chatRoomId', 'isRunning', 'lastActiveGoals', 'goalsArchive'], (result) => {
        if (!result.isRunning || !result.chatRoomId) return;

        // Skip if we hit a rate limit recently
        if (Date.now() - lastRateLimitTime < RATE_LIMIT_COOLDOWN) {
            console.warn('[FanslyBot] Polling suspended due to recent rate limit.');
            return;
        }

        fetch(`https://apiv3.fansly.com/api/v1/chatrooms?ids=${result.chatRoomId}`)
            .then(r => {
                if (r.status === 429) {
                    lastRateLimitTime = Date.now();
                    throw new Error('Rate limited (429)');
                }
                return r.json();
            })
            .then(data => {
                if (data.success && data.response && data.response[0]) {
                    const activeGoals = data.response[0].activeGoals || [];
                    const lastActiveGoals = result.lastActiveGoals || [];
                    let archive = result.goalsArchive || [];
                    let archiveUpdated = false;

                    // Identify disappeared goals
                    lastActiveGoals.forEach(oldGoal => {
                        const stillActive = activeGoals.find(g => g.id === oldGoal.id);
                        if (!stillActive) {
                            // Archive it
                            const current = (oldGoal.currentAmount || 0);
                            const target = (oldGoal.goalAmount || 1);

                            // Prevent duplicates in case of quick polls
                            const alreadyArchived = archive.find(a => a.id === oldGoal.id && (Date.now() - a.timestamp < 300000)); // 5 min window
                            if (!alreadyArchived) {
                                archive.unshift({
                                    id: oldGoal.id,
                                    label: oldGoal.label,
                                    description: oldGoal.description,
                                    currentAmount: current,
                                    goalAmount: target,
                                    reached: current >= target,
                                    timestamp: Date.now()
                                });
                                archiveUpdated = true;
                            }
                        }
                    });

                    if (archiveUpdated) {
                        if (archive.length > 50) archive = archive.slice(0, 50);
                        chrome.storage.local.set({ goalsArchive: archive });
                    }

                    chrome.storage.local.set({ lastActiveGoals: activeGoals });

                    // 🟠 Goal Queue: if a slot just opened, auto-sync the next queued goal
                    const slotJustOpened = activeGoals.length < lastActiveGoals.length;
                    if (slotJustOpened) {
                        console.log(`[FanslyBot] [Queue] Slot opened (${lastActiveGoals.length} → ${activeGoals.length}). Checking queue...`);
                        autoSyncNextQueued();
                    }

                    chrome.runtime.sendMessage({
                        action: 'active_goals_updated',
                        data: activeGoals,
                        archive: archive
                    }).catch(() => { });
                }
            })
            .catch(err => console.error('[FanslyBot] Failed to poll active goals:', err));
    });
}

function sendToTabs(content) {
    const now = Date.now();
    if (now - lastGlobalMessageTime < GLOBAL_MESSAGE_COOLDOWN) {
        console.warn(`[FanslyBot] Burst suppression: Ignoring message to prevent potential spam loop.`);
        return;
    }
    lastGlobalMessageTime = now;

    // Emergency Rate Breaker
    while (emergencyMsgTimestamps.length > 0 && now - emergencyMsgTimestamps[0] > EMERGENCY_WINDOW_MS) {
        emergencyMsgTimestamps.shift();
    }
    if (emergencyMsgTimestamps.length >= EMERGENCY_MAX_MSGS) {
        console.error(`[FanslyBot] 🚨 EMERGENCY RATE BREAKER TRIGGERED — dropping message.`);
        return;
    }
    emergencyMsgTimestamps.push(now);

    chrome.tabs.query({ url: ["*://*.fansly.com/live/*", "*://*.fansly.com/creator/streaming*"] }, (tabs) => {
        for (let tab of tabs) {
            chrome.tabs.sendMessage(tab.id, {
                action: 'post_tip_menu',
                content: content
            }, () => {
                if (chrome.runtime.lastError) { /* ignore */ }
            });
        }
    });
}
