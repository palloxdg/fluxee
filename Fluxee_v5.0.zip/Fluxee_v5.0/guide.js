const sections = document.querySelectorAll('section');
const navLinks = document.querySelectorAll('nav a');
const mainContainer = document.getElementById('main-scroll');

// Use IntersectionObserver for stable and efficient section tracking
const observerOptions = {
    root: mainContainer,
    rootMargin: '-10% 0px -80% 0px', // Precise trigger zone near top
    threshold: 0
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const id = entry.target.getAttribute('id');
            updateActiveLink(id);
        }
    });
}, observerOptions);

sections.forEach(section => observer.observe(section));

function updateActiveLink(id) {
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
        }
    });
}
