// --- Fluxee v5.0: Ultra-Stable Content Script ---

(function () {
    // 1. CONTEXT GUARD: If this script is orphaned, stop immediately
    function isContextValid() {
        try {
            return (typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id);
        } catch (e) {
            return false;
        }
    }

    // 2. PAGE GUARD: Only run on the creator streaming dashboard
    function isPageSupported() {
        return window.location.href.includes('/creator/streaming');
    }
    function getUsernameFromUrl() {
        const url = window.location.href;
        const parts = window.location.pathname.split('/');

        // 1. Standard Live Page: fansly.com/live/Username
        if (parts.length >= 3 && parts[1] === 'live') {
            return parts[2];
        }

        // 2. Creator Streaming Dashboard: fansly.com/creator/streaming
        if (url.includes('/creator/streaming')) {
            // Find current user's username if possible from page
            const avatarLink = document.querySelector('app-account-avatar a[href*="/"]');
            if (avatarLink) {
                const pathParts = avatarLink.getAttribute('href').split('/');
                return pathParts[pathParts.length - 1];
            }
        }
        return null;
    }

    if (!isContextValid()) return;

    let botRunning = false;
    let lastPulseTime = 0;
    let mainObserver = null;
    let streamerUsername = "";
    let identityResolved = false; // FIX 2: Block mods until we know who we are
    let lastRateLimitTime = 0;
    const RATE_LIMIT_COOLDOWN = 10 * 60 * 1000; // 10 minutes
    let lastBotMessageTime = 0;
    const BOT_IGNORE_WINDOW = 2500;
    const MOD_USER_COOLDOWN = 30000;
    const modUserLastWarned = new Map();
    // Tip dedup hash cache — sessionStorage-backed so it survives SPA navigation
    const MAX_HASH_CACHE = 200;
    const SESSION_HASH_KEY = 'fluxee_tip_hashes';
    function loadHashCache() {
        try {
            const raw = sessionStorage.getItem(SESSION_HASH_KEY);
            return raw ? new Set(JSON.parse(raw)) : new Set();
        } catch (e) { return new Set(); }
    }
    function saveHashCache(set) {
        try { sessionStorage.setItem(SESSION_HASH_KEY, JSON.stringify([...set])); } catch (e) {}
    }
    const recentMessageHashes = loadHashCache();

    // Caps Filter Settings
    let enableCapsFilter = false;
    let minCapsLength = 5;
    let capsThreshold = 70;
    let capsWarningMsg = "⚠️ {user}, please avoid using too many CAPS! ⚠️";

    // Links Filter Settings
    let enableLinksFilter = false;
    let linksWarningMsg = "⚠️ {user}, please do not post links! ⚠️";
    let whitelistedLinksList = ['fansly.com', 'twitter.com'];

    // Word Filter Settings
    let enableWordFilter = false;
    let bannedWords = [];
    let wordWarningMsg = "⚠️ {user}, please avoid using forbidden words! ⚠️";

    // Paragraphs Filter Settings
    let enableParagraphsFilter = false;
    let maxChars = 250;
    let maxNewlines = 5;
    let paragraphsWarningMsg = "⚠️ {user}, your message is too long or has too many paragraphs! ⚠️";

    // Symbols Filter Settings
    let enableSymbolsFilter = false;
    let minSymbolsLength = 10;
    let symbolsThreshold = 50;
    let symbolsWarningMsg = "⚠️ {user}, please avoid excessive symbols! ⚠️";

    const commonTlds = [
        '.com', '.net', '.org', '.io', '.gov', '.edu', '.co', '.uk', '.ca', '.au',
        '.de', '.fr', '.it', '.es', '.biz', '.info', '.me', '.tv', '.xyz', '.site',
        '.online', '.top', '.vip', '.tech', '.store', '.app', '.blog'
    ];

    // Exclusion Settings
    let excludeStreamer = true; // Hardcoded Always ON
    let excludeModerators = true; // Hardcoded Always ON
    let excludeSubscribers = false;
    let excludeCreators = false;

    // 3. STATE SYNC
    function updateBotState() {
        if (!isContextValid()) {
            killScript();
            return;
        }
        chrome.storage.local.get([
            'isRunning', 'streamerUsername',
            'enableCapsFilter', 'minCapsLength', 'capsThreshold', 'capsWarningMsg',
            'enableLinksFilter', 'linksWarningMsg', 'whitelistedLinks',
            'enableWordFilter', 'bannedWords', 'wordWarningMsg',
            'enableParagraphsFilter', 'maxChars', 'maxNewlines', 'paragraphsWarningMsg',
            'enableSymbolsFilter', 'minSymbolsLength', 'symbolsThreshold', 'symbolsWarningMsg',
            'excludeStreamer', 'excludeModerators', 'excludeSubscribers', 'excludeCreators'
        ], (result) => {
            if (chrome.runtime.lastError) {
                killScript();
                return;
            }
            botRunning = !!result.isRunning;
            if (result.streamerUsername) streamerUsername = result.streamerUsername;

            enableCapsFilter = !!result.enableCapsFilter;
            if (result.minCapsLength) minCapsLength = parseInt(result.minCapsLength);
            if (result.capsThreshold) capsThreshold = parseInt(result.capsThreshold);
            if (result.capsWarningMsg) capsWarningMsg = result.capsWarningMsg;

            enableLinksFilter = !!result.enableLinksFilter;
            if (result.linksWarningMsg) linksWarningMsg = result.linksWarningMsg;
            if (result.whitelistedLinks) whitelistedLinksList = result.whitelistedLinks;

            enableWordFilter = !!result.enableWordFilter;
            if (result.bannedWords) {
                if (typeof result.bannedWords === 'string') {
                    bannedWords = result.bannedWords.split(',').map(w => w.trim().toLowerCase()).filter(w => w.length > 0);
                } else {
                    bannedWords = result.bannedWords;
                }
            }
            if (result.wordWarningMsg) wordWarningMsg = result.wordWarningMsg;

            enableParagraphsFilter = !!result.enableParagraphsFilter;
            if (result.maxChars) maxChars = parseInt(result.maxChars);
            if (result.maxNewlines !== undefined) maxNewlines = parseInt(result.maxNewlines);
            if (result.paragraphsWarningMsg) paragraphsWarningMsg = result.paragraphsWarningMsg;

            enableSymbolsFilter = !!result.enableSymbolsFilter;
            if (result.minSymbolsLength) minSymbolsLength = parseInt(result.minSymbolsLength);
            if (result.symbolsThreshold) symbolsThreshold = parseInt(result.symbolsThreshold);
            if (result.symbolsWarningMsg) symbolsWarningMsg = result.symbolsWarningMsg;

            if (result.excludeSubscribers !== undefined) excludeSubscribers = !!result.excludeSubscribers;
            if (result.excludeCreators !== undefined) excludeCreators = !!result.excludeCreators;
        });
    }

    function killScript() {
        botRunning = false;
        if (mainObserver) {
            try { mainObserver.disconnect(); } catch (e) { }
            mainObserver = null;
        }
    }

    // Initial load
    updateBotState();

    // Listen for changes
    chrome.storage.onChanged.addListener((changes) => {
        if (!isContextValid()) { killScript(); return; }
        if (changes.isRunning) {
            botRunning = !!changes.isRunning.newValue;
        }
        if (changes.streamerUsername) {
            streamerUsername = changes.streamerUsername.newValue;
        }
        if (changes.enableCapsFilter) enableCapsFilter = !!changes.enableCapsFilter.newValue;
        if (changes.minCapsLength) minCapsLength = parseInt(changes.minCapsLength.newValue);
        if (changes.capsThreshold) capsThreshold = parseInt(changes.capsThreshold.newValue);
        if (changes.capsWarningMsg) capsWarningMsg = changes.capsWarningMsg.newValue;

        if (changes.enableLinksFilter) enableLinksFilter = !!changes.enableLinksFilter.newValue;
        if (changes.linksWarningMsg) linksWarningMsg = changes.linksWarningMsg.newValue;
        if (changes.whitelistedLinks) whitelistedLinksList = changes.whitelistedLinks.newValue;

        if (changes.enableWordFilter) enableWordFilter = !!changes.enableWordFilter.newValue;
        if (changes.bannedWords) {
            const val = changes.bannedWords.newValue;
            if (typeof val === 'string') {
                bannedWords = val.split(',').map(w => w.trim().toLowerCase()).filter(w => w.length > 0);
            } else {
                bannedWords = val || [];
            }
        }
        if (changes.wordWarningMsg) wordWarningMsg = changes.wordWarningMsg.newValue;

        if (changes.enableParagraphsFilter !== undefined) enableParagraphsFilter = changes.enableParagraphsFilter.newValue;
        if (changes.maxChars !== undefined) maxChars = changes.maxChars.newValue;
        if (changes.maxNewlines !== undefined) maxNewlines = changes.maxNewlines.newValue;
        if (changes.paragraphsWarningMsg) paragraphsWarningMsg = changes.paragraphsWarningMsg.newValue;

        if (changes.enableSymbolsFilter !== undefined) enableSymbolsFilter = changes.enableSymbolsFilter.newValue;
        if (changes.minSymbolsLength) minSymbolsLength = parseInt(changes.minSymbolsLength.newValue);
        if (changes.symbolsThreshold) symbolsThreshold = parseInt(changes.symbolsThreshold.newValue);
        if (changes.symbolsWarningMsg) symbolsWarningMsg = changes.symbolsWarningMsg.newValue;

        if (changes.excludeSubscribers !== undefined) excludeSubscribers = changes.excludeSubscribers.newValue;
        if (changes.excludeCreators) excludeCreators = !!changes.excludeCreators.newValue;
    });

    // Handle incoming messages
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (!isContextValid()) { killScript(); return; }
        if (request.action === 'post_tip_menu') {
            postMessageToChat(request.content);
        } else if (request.action === 'refresh_identity') {
            const username = getUsernameFromUrl();
            resolveIdentity(username);
        } else if (request.action === 'get_session_context') {
            handleGetSessionContext(sendResponse);
            return true;
        }
    });

    async function handleGetSessionContext(sendResponse) {
        try {
            const storage = await chrome.storage.local.get(['chatRoomId']);
            const chatRoomId = storage.chatRoomId;

            const context = {
                chatRoomId: chatRoomId,
                csrf: document.cookie.match(/fansly-csrftoken=([^;]+)/)?.[1] || '',
                token: ''
            };

            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                const val = localStorage.getItem(key);
                if (!val) continue;

                if ((key.includes('token') || key.includes('session') || key.includes('auth')) && val.length > 20) {
                    if (!val.startsWith('{')) {
                        context.token = val;
                    } else {
                        try {
                            const parsed = JSON.parse(val);
                            const possibleToken = parsed.token || parsed.authToken || parsed.sessionToken || parsed.authorization;
                            if (possibleToken) context.token = possibleToken;
                        } catch (e) { }
                    }
                }
            }
            sendResponse(context);
        } catch (e) {
            sendResponse({ error: e.message });
        }
    }

    // 4. SAFE COMMUNICATION
    function safeSendMessage(message) {
        if (!botRunning || !isPageSupported()) return;
        if (!isContextValid()) {
            killScript();
            return;
        }

        try {
            chrome.runtime.sendMessage(message, () => {
                if (chrome.runtime.lastError) { /* ignore */ }
            });
        } catch (e) {
            killScript();
        }
    }

    // 5. CHAT MONITOR
    function startChatMonitor() {
        if (!isContextValid()) return;
        if (!isPageSupported()) {
            // Keep checking since Fansly is a single-page app
            setTimeout(startChatMonitor, 5000);
            return;
        }

        if (mainObserver) mainObserver.disconnect();

        let mutationDebounceTimer = null;
        let pendingNodes = [];

        function flushPendingNodes() {
            mutationDebounceTimer = null;
            if (Date.now() - lastBotMessageTime < BOT_IGNORE_WINDOW) {
                pendingNodes = [];
                return;
            }
            const toProcess = pendingNodes.splice(0);
            for (const node of toProcess) {
                try { handleNewNode(node); } catch (e) {}
            }
        }

        mainObserver = new MutationObserver((mutations) => {
            if (!isContextValid()) { killScript(); return; }
            if (!isPageSupported()) return;
            for (const mutation of mutations) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType !== 1) continue;
                    if (node.closest && node.closest('.chat-input, .chat-input-wrapper, .message-composer, [class*="chat-input"]')) continue;
                    pendingNodes.push(node);
                }
            }
            if (mutationDebounceTimer) clearTimeout(mutationDebounceTimer);
            mutationDebounceTimer = setTimeout(flushPendingNodes, 200);
        });

        mainObserver.observe(document.body, { childList: true, subtree: true });
    }
    function containsIllegalLink(text) {
        if (!text) return false;

        // Regex to find potential links/domains
        const linkRegex = /(?:https?:\/\/|www\.)[^\s]+|([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b/ig;
        let match;

        while ((match = linkRegex.exec(text)) !== null) {
            const fullMatch = match[0].toLowerCase();
            const domainOnly = (match[1] || "").toLowerCase();

            // Check if whitelisted
            const isWhitelisted = whitelistedLinksList.some(w => {
                const normalizedW = w.toLowerCase().trim();
                return fullMatch.includes(normalizedW) || (domainOnly && domainOnly.includes(normalizedW));
            }) || fullMatch.includes('fansly.com'); // Hardcoded fansly whitelist

            if (isWhitelisted) continue;

            // 1. Explicit protocol or www is always a link
            if (fullMatch.startsWith('http') || fullMatch.startsWith('www.')) return true;

            // 2. Typos like "Hello.World" check
            if (domainOnly) {
                const lastDotIndex = domainOnly.lastIndexOf('.');
                if (lastDotIndex !== -1) {
                    const tld = domainOnly.substring(lastDotIndex);
                    if (commonTlds.includes(tld)) {
                        return true; // It's a common TLD like .com, trigger filter
                    }
                }
            }
        }
        return false;
    }

    function containsBannedWord(text) {
        if (!text || !bannedWords || bannedWords.length === 0) return false;
        const lowerText = text.toLowerCase();
        return bannedWords.some(word => lowerText.includes(word.toLowerCase()));
    }

    function isParagraphViolation(text) {
        if (!text) return false;

        // 1. Check Character Length
        if (text.length > maxChars) return true;

        // 2. Check Newline Count
        const newlineCount = (text.match(/\n/g) || []).length;
        if (newlineCount > maxNewlines) return true;

        return false;
    }

    function isSymbolsViolation(text) {
        if (!text || text.length < minSymbolsLength) return false;

        // Count symbols (non-alphanumeric, non-whitespace across all languages)
        // \p{L} = Any Letter, \p{N} = Any Number, \s = Whitespace
        const matches = text.match(/[^\p{L}\p{N}\s]/gu);
        const symbolCount = matches ? matches.length : 0;

        const density = (symbolCount / text.length) * 100;
        return density > symbolsThreshold;
    }

    function handleNewNode(node) {
        if (!botRunning) return;

        // Guard: Don't process the same node twice (DOM attribute)
        if (node.nodeType !== 1 || node.hasAttribute('data-fansly-bot-processed')) return;
        node.setAttribute('data-fansly-bot-processed', 'true');

        const text = node.innerText || node.textContent;
        if (!text || typeof text !== 'string') return;

        // FIX 5: In-memory hash dedup (handles virtual-scroll DOM recycling)
        const msgHash = text.trim().substring(0, 100);
        if (msgHash && recentMessageHashes.has(msgHash)) return;
        if (msgHash) {
            recentMessageHashes.add(msgHash);
            if (recentMessageHashes.size > MAX_HASH_CACHE) {
                recentMessageHashes.delete(recentMessageHashes.values().next().value);
            }
            saveHashCache(recentMessageHashes);
        }

        // --- UNIVERSAL SENDER IDENTIFICATION ---
        let username = "";
        const userLink = node.querySelector('a[href*="/"] , .username, .chat-message-username, .author, [appaccountcard]');
        if (userLink && userLink.innerText) {
            username = userLink.innerText.trim();
        } else {
            // Fallback username parsing from text for all node types
            const match = text.match(/@([a-zA-Z0-9_]+)/i) ||
                text.match(/^\s*([a-zA-Z0-9_]+)\s+tipped/i) ||
                text.match(/^\s*([a-zA-Z0-9_]+):/);
            if (match && match[1]) username = match[1];
        }

        if (username) username = username.replace(/^@/, '').split(' ')[0];

        // 🐱 Easter Egg: anyone (streamer OR viewer) typing "oscar" triggers the cat
        // Must be BEFORE the self-guard return so the streamer can use it too
        if (/\boscar\b/i.test(text)) {
            chrome.runtime.sendMessage({ action: 'chat_oscar' }).catch(() => { });
        }

        // --- STRANGER DANGER / SELF-TRIGGER GUARD ---
        // (prevents the BOT from acting on the streamer's messages in moderation)
        if (streamerUsername && username && username.toLowerCase() === streamerUsername.toLowerCase()) {
            return;
        }

        // --- ROLE DETECTION (For exclusions) ---
        function isExcludedUser(node, username) {
            // 1. Streamer
            if (excludeStreamer) {
                if (streamerUsername && username && username.toLowerCase() === streamerUsername.toLowerCase()) return true;
                // Double check for streamer badge / accountcard as fallback
                if (node.querySelector('[appaccountcard*="/live/"]')) return true;
            }

            // 2. Moderators (Shield icon)
            if (excludeModerators) {
                if (node.querySelector('app-svg-icon[icon*="shield"], .fa-shield-halved, .mod-icon')) return true;
            }

            // 3. Subscribers (Star icon)
            if (excludeSubscribers) {
                if (node.querySelector('app-svg-icon[icon*="star"], .fa-star, .sub-icon, .subscriber-badge')) return true;
            }

            // 4. Other Creators (Blue checkmark / verified)
            if (excludeCreators) {
                if (node.querySelector('app-svg-icon[icon*="check"], app-svg-icon[icon*="verified"], .fa-check, .verified-icon')) return true;
            }

            return false;
        }

        // A. Commands
        const commandMatch = text.match(/(!\w+)/);
        if (commandMatch && !text.includes('⚠️') && !text.includes('cooldown')) {
            // Require identity resolved before processing commands
            if (!identityResolved) return;
            // Dedup: prevent virtual-scroll replays
            const cmdHash = `cmd:${username}:${commandMatch[1]}:${text.slice(0, 60)}`;
            if (recentMessageHashes.has(cmdHash)) return;
            recentMessageHashes.add(cmdHash);
            if (recentMessageHashes.size > MAX_HASH_CACHE) {
                recentMessageHashes.delete(recentMessageHashes.values().next().value);
            }
            saveHashCache(recentMessageHashes);
            safeSendMessage({ action: 'chat_command', command: commandMatch[1] });
            return;
        }

        // B. Tips
        // ONLY rely on native Fansly notification elements to avoid feedback loops
        // Guard: Ignore icons inside common badge/avatar/header containers found in Fansly's broadcaster UI
        if (node.closest('.user-badge, .avatar-badges, .badges, .chat-message-badges, .chat-item-badges, .broadcaster-badge, .user-icon, .user-icon2')) return;

        // Specific Guard: Ignore icons often found in streamer/verified headers (Camera, Badge, Check, Star)
        if (node.querySelector('app-svg-icon[icon*="video"], app-svg-icon[icon*="camera"], app-svg-icon[icon*="verified"], app-svg-icon[icon*="check"], i.fa-video, i.fa-badge, i.fa-check, i.fa-star')) return;

        // Subscription Guard: If the text contains "subscribed" related keywords, it is NOT a tip to be thanked
        const lowerText = text.toLowerCase();
        if (lowerText.includes('subscribed') || lowerText.includes('subscription')) return;

        const isNativeTip = node.querySelector('app-svg-icon[icon="gift"], .chat-message-notification, .chat-item-notification, .user-icon.tip, .icon-box.tip, i.fa-gift') ||
            node.matches('app-svg-icon[icon="gift"], .chat-message-notification, .chat-item-notification, .user-icon.tip, .icon-box.tip');

        if (isNativeTip) {
            // Filter out common bot/gif false positives
            if (node.querySelector('img[src*="tenor.com"], img[src*="giphy.com"]')) return;

            let amount = "";
            const balanceDisplay = node.querySelector('app-balance-display');
            if (balanceDisplay && balanceDisplay.innerText) {
                amount = balanceDisplay.innerText.replace('$', '').trim();
            } else {
                const textWithoutTime = text.replace(/\b\d{1,2}:\d{2}\b/, '');
                const amountMatch = textWithoutTime.match(/(\$?\d+)/);
                if (amountMatch) amount = amountMatch[1].replace('$', '');
            }

            // Real-Tip Guard: Skip if amount is 0 or empty (prevents reacting to broadcaster's $0 tip-body placeholders)
            if (amount && amount !== "0" && username) {
                safeSendMessage({ action: 'new_tipper', username, amount });
            }
        }
        // C. Activity
        else if (text.length > 0) {
            const isMsg = node.matches('.chat-item, .chat-message, [class*="chat-message"]') ||
                node.querySelector('.chat-item, .chat-message, [class*="chat-message"]');

            if (isMsg) {
                const messageText = node.querySelector('.chat-message-text, .text, .content')?.innerText || text;

                // FIX 2: Only apply moderation after identity is confirmed
                // FIX 4: Short-circuit after first matched filter (one warning per message)
                if (identityResolved && !isExcludedUser(node, username)) {
                    const lastWarnedTime = modUserLastWarned.get(username) || 0;
                    const skipMod = (Date.now() - lastWarnedTime < MOD_USER_COOLDOWN);
                    let warningPosted = false;
                    if (skipMod) warningPosted = true;

                    // Apply Caps Filter
                    if (!warningPosted && enableCapsFilter) {
                        if (messageText && messageText.length >= minCapsLength) {
                            const letters = messageText.replace(/[^a-zA-Z]/g, '');
                            if (letters.length > 0) {
                                const capsCount = (letters.match(/[A-Z]/g) || []).length;
                                const capsPercent = (capsCount / letters.length) * 100;
                                if (capsPercent >= capsThreshold) {
                                    const response = capsWarningMsg.replace('{user}', username || 'User');
                                    safeSendMessage({ action: 'post_moderation_warning', message: response });
                                    modUserLastWarned.set(username || '', Date.now());
                                    warningPosted = true;
                                }
                            }
                        }
                    }

                    // Apply Links Filter
                    if (!warningPosted && enableLinksFilter) {
                        if (containsIllegalLink(messageText)) {
                            const response = linksWarningMsg.replace('{user}', username || 'User');
                            safeSendMessage({ action: 'post_moderation_warning', message: response });
                                    modUserLastWarned.set(username || '', Date.now());
                            warningPosted = true;
                        }
                    }

                    // Apply Word Filter
                    if (!warningPosted && enableWordFilter) {
                        if (containsBannedWord(messageText)) {
                            const response = wordWarningMsg.replace('{user}', username || 'User');
                            safeSendMessage({ action: 'post_moderation_warning', message: response });
                                    modUserLastWarned.set(username || '', Date.now());
                            warningPosted = true;
                        }
                    }

                    // Apply Paragraphs Filter
                    if (!warningPosted && enableParagraphsFilter) {
                        if (isParagraphViolation(messageText)) {
                            console.log(`[FanslyBot] Paragraph violation by ${username}. Length: ${messageText.length}, Newlines: ${(messageText.match(/\n/g) || []).length}`);
                            const response = paragraphsWarningMsg.replace('{user}', username || 'User');
                            safeSendMessage({ action: 'post_moderation_warning', message: response });
                                    modUserLastWarned.set(username || '', Date.now());
                            warningPosted = true;
                        }
                    }

                    // Apply Symbols Filter
                    if (!warningPosted && enableSymbolsFilter) {
                        if (isSymbolsViolation(messageText)) {
                            console.log(`[FanslyBot] Symbols violation by ${username}. Density: > ${symbolsThreshold}%`);
                            const response = symbolsWarningMsg.replace('{user}', username || 'User');
                            safeSendMessage({ action: 'post_moderation_warning', message: response });
                                    modUserLastWarned.set(username || '', Date.now());
                        }
                    }
                }
            }

            const now = Date.now();
            if (now - lastPulseTime > 1000) {
                safeSendMessage({ action: 'chat_message_received' });
                lastPulseTime = now;
            }
        }
    }

    // --- Core Helper Functions ---
    function setNativeValue(element, value) {
        const valueSetter = Object.getOwnPropertyDescriptor(element, 'value')?.set;
        const prototype = Object.getPrototypeOf(element);
        const prototypeValueSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
        if (valueSetter && valueSetter !== prototypeValueSetter) {
            prototypeValueSetter.call(element, value);
        } else if (prototypeValueSetter) {
            prototypeValueSetter.call(element, value);
        } else {
            element.value = value;
        }
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function postMessageToChat(message) {
        if (!isPageSupported()) return;
        const textInput = document.querySelector('textarea.message-input, .chat-input-textarea, .chat-input textarea, [contenteditable="true"]');
        if (!textInput) return;

        // Pre-write guard: don't overwrite if streamer is mid-typing
        const isTextarea = textInput.tagName.toLowerCase() === 'textarea' || textInput.tagName.toLowerCase() === 'input';
        const currentValue = isTextarea ? textInput.value : textInput.innerText;
        if (currentValue && currentValue.trim().length > 0) return;

        lastBotMessageTime = Date.now();

        if (isTextarea) {
            setNativeValue(textInput, message);
        } else {
            textInput.innerText = message;
            textInput.dispatchEvent(new Event('input', { bubbles: true }));
        }

        setTimeout(() => {
            const sendButton = document.querySelector('.chat-input-send-button, .message-input + button, button[aria-label*="Send"], button[title*="Send"], .chat-input button');
            if (sendButton) {
                sendButton.click();
            } else {
                textInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, keyCode: 13, key: 'Enter', code: 'Enter' }));
            }

            // 800ms safety net: clear if send failed
            setTimeout(() => {
                const stillThere = isTextarea ? textInput.value : textInput.innerText;
                if (stillThere && stillThere.trim() === message.trim()) {
                    if (isTextarea) setNativeValue(textInput, '');
                    else { textInput.innerText = ''; textInput.dispatchEvent(new Event('input', { bubbles: true })); }
                }
            }, 800);
        }, 500);
    }

    // Startup Delay
    setTimeout(() => {
        startChatMonitor();
        handleUrlChange();
    }, 3000);

    function handleUrlChange() {
        if (!isPageSupported()) return;

        const username = getUsernameFromUrl();
        console.log(`[FanslyBot] [Content] URL changed. Initializing identity check (User: ${username || 'None'}).`);
        resolveIdentity(username);
    }

    async function resolveIdentity(username) {
        // Skip if we hit a rate limit recently
        if (Date.now() - lastRateLimitTime < RATE_LIMIT_COOLDOWN) {
            console.warn('[FanslyBot] [Content] Identity check suspended due to recent rate limit.');
            return;
        }

        try {
            const accountUrl = username
                ? `https://apiv3.fansly.com/api/v1/account?usernames=${username}`
                : `https://apiv3.fansly.com/api/v1/account/me`;

            console.log(`[FanslyBot] [Content] Resolving identity via ${accountUrl}`);
            const accountRes = await fetch(accountUrl);

            if (accountRes.status === 429) {
                lastRateLimitTime = Date.now();
                throw new Error('Rate limited (429)');
            }

            const accountData = await accountRes.json();

            if (!accountData.success || !accountData.response) {
                throw new Error('Account lookup failed');
            }

            const profile = Array.isArray(accountData.response) ? accountData.response[0] : accountData.response;
            if (!profile || !profile.id) throw new Error('Could not find profile ID');

            console.log(`[FanslyBot] [Content] Identified creator: ${profile.username} (ID: ${profile.id})`);

            const channelRes = await fetch(`https://apiv3.fansly.com/api/v1/streaming/channel/${profile.id}`);
            const channelData = await channelRes.json();

            if (!channelData.success || !channelData.response || !channelData.response.chatRoomId) {
                throw new Error('Could not resolve ChatRoomId');
            }

            const chatRoomId = channelData.response.chatRoomId;
            console.log(`[FanslyBot] [Content] Successfully resolved ChatRoomId: ${chatRoomId}`);

            identityResolved = true; // FIX 2: Unlock moderation now that we know who we are
            streamerUsername = profile.username; // Eagerly update locally too
            chrome.runtime.sendMessage({
                action: 'identity_resolved',
                chatRoomId: chatRoomId,
                streamerUsername: profile.username
            });
        } catch (e) {
            console.error('[FanslyBot] [Content] Identity resolution error:', e);
            chrome.runtime.sendMessage({ action: 'identity_failed', error: e.message });
        }
    }

    // Monitor for URL changes (Fansly is an SPA)
    let lastUrl = location.href;
    new MutationObserver(() => {
        const url = location.href;
        if (url !== lastUrl) {
            lastUrl = url;
            handleUrlChange();
        }
    }).observe(document, { subtree: true, childList: true });
})();
