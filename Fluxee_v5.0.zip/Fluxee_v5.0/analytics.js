// --- Fluxee v5.0: Standalone Analytics & Goals Logic ---

// UI Elements
const tipsTabBtn = document.getElementById('tipsTabBtn');
const goalsTabBtn = document.getElementById('goalsTabBtn');
const tipsTabContent = document.getElementById('tipsTabContent');
const goalsTabContent = document.getElementById('goalsTabContent');

const analyticsTimeframe = document.getElementById('analyticsTimeframe');
const analyticsList = document.getElementById('analyticsList');
const analyticsTotalTips = document.getElementById('analyticsTotalTips');
const analyticsTotalRev = document.getElementById('analyticsTotalRev');
const analyticsNetRev = document.getElementById('analyticsNetRev');
const peakHoursChart = document.getElementById('peakHoursChart');
const untippedList = document.getElementById('untippedList');

const goalProgressBar = document.getElementById('goalProgressBar');
const goalProgressText = document.getElementById('goalProgressText');
const displayGoalName = document.getElementById('displayGoalName');
const goalNameInput = document.getElementById('goalName');
const goalAmountInput = document.getElementById('goalAmount');
const saveGoalBtn = document.getElementById('saveGoalBtn');
const resetGoalBtn = document.getElementById('resetGoalBtn');

const liveGoalsGlass = document.getElementById('liveGoalsGlass');
const goalsArchiveList = document.getElementById('goalsArchiveList');
const tagPerformanceList = document.getElementById('tagPerformanceList');
const masterTagsList = document.getElementById('masterTagsList');
const newTagInput = document.getElementById('newTagInput');
const addTagBtn = document.getElementById('addTagBtn');
const clearAnalyticsBtn = document.getElementById('clearAnalyticsBtn');

// Goal Management Selectors
const goalTitleInputPage = document.getElementById('goalTitleInput');
const goalTextInputPage = document.getElementById('goalTextInput');
const goalTargetInputPage = document.getElementById('goalTargetInput');
const saveGoalPageBtn = document.getElementById('saveGoalPageBtn');
const clearGoalPageBtn = document.getElementById('clearGoalPageBtn');
const goalsListContainer = document.getElementById('goalsListContainer');
const connectionStatus = document.getElementById('connectionStatus');
const refreshConnBtn = document.getElementById('refreshConnBtn');

// Notification Elements
const toastContainer = document.getElementById('toast-container');
const confirmModalOverlay = document.getElementById('confirm-modal-overlay');
const confirmModalMessage = document.getElementById('confirm-modal-message');
const confirmModalYes = document.getElementById('confirm-modal-yes');
const confirmModalNo = document.getElementById('confirm-modal-no');

const sortItem = document.getElementById('sortItem');
const sortCount = document.getElementById('sortCount');
const sortTotal = document.getElementById('sortTotal');

// State
let tipAnalytics = [];
let analyticsSort = { column: 'total', direction: 'desc' };
let last24hReset = 0;
let goalResetTimestamp = 0;
let analyticsGoal = { name: "", amount: 0 };
let currentLang = 'en';
let goalsArchive = [];
let goalTags = [];
let goals = [];
let goalQueue = []; // ordered array of goal IDs waiting to be auto-synced
let currentChatRoomId = null;
let editingGoalId = null;
let menus = {};
let currentTaggingGoalId = null;

async function loadState() {
    if (typeof chrome === 'undefined' || !chrome.storage) {
        console.warn('chrome.storage is not available. Using default state.');
        currentLang = 'en';
        applyLanguage(currentLang);
        initHandlers();
        return;
    }
    const result = await chrome.storage.local.get([
        'tipAnalytics', 'last24hReset', 'goalResetTimestamp', 'analyticsGoal',
        'currentLang', 'goalsArchive', 'goalTags', 'goals', 'menus', 'chatRoomId', 'goalQueue'
    ]);

    tipAnalytics = result.tipAnalytics || [];
    last24hReset = result.last24hReset || 0;
    goalResetTimestamp = result.goalResetTimestamp || 0;
    analyticsGoal = result.analyticsGoal || { name: "", amount: 0 };
    currentLang = result.currentLang || 'en';
    goalsArchive = result.goalsArchive || [];
    goalTags = result.goalTags || [];
    goals = result.goals || [];
    goalQueue = Array.isArray(result.goalQueue) ? result.goalQueue : [];
    menus = result.menus || {};
    currentChatRoomId = result.chatRoomId || null;

    applyLanguage(currentLang);
    initHandlers();
}

function saveState() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;
    chrome.storage.local.set({
        tipAnalytics: tipAnalytics,
        last24hReset: last24hReset,
        goalResetTimestamp: goalResetTimestamp,
        analyticsGoal: analyticsGoal,
        currentLang: currentLang,
        goalsArchive: goalsArchive,
        goalTags: goalTags,
        goals: goals,
        menus: menus
    });
}

function applyLanguage(lang) {
    currentLang = lang;
    const trans = uiTranslations[lang];
    if (!trans) return;

    document.querySelectorAll('.lang-selector .lang-flag').forEach(flag => {
        flag.classList.toggle('active', flag.dataset.lang === lang);
    });

    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (trans[key]) el.innerText = trans[key];
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.dataset.i18nPlaceholder;
        if (trans[key]) el.placeholder = trans[key];
    });

    renderAll();
}

function renderAll() {
    renderAnalytics();
    renderTagManagement();
    renderTagPerformance();
    renderGoalsList();
}

// --- Custom Notification Helpers ---
function showToast(message, duration = 3000) {
    if (!toastContainer) return;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>${message}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

function showConfirm(message, onConfirm) {
    if (!confirmModalOverlay) return;
    confirmModalMessage.textContent = message;
    confirmModalOverlay.style.display = 'flex';

    const cleanup = () => {
        confirmModalOverlay.style.display = 'none';
        confirmModalYes.onclick = null;
        confirmModalNo.onclick = null;
    };

    confirmModalYes.onclick = () => {
        cleanup();
        if (onConfirm) onConfirm();
    };

    confirmModalNo.onclick = () => {
        cleanup();
    };
}

// --- INITIALIZATION ---
function initHandlers() {
    // Listen for sync results from background (more reliable than message callback)
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.onChanged.addListener((changes) => {
            if (changes.lastSyncResult && changes.lastSyncResult.newValue) {
                const res = changes.lastSyncResult.newValue;
                // Only show if it's new (last 5 seconds)
                if (Date.now() - res.time < 5000) {
                    if (res.success) {
                        showToast(uiTranslations[currentLang].syncSuccess || "Goal synced successfully!");
                    } else {
                        const baseErr = uiTranslations[currentLang].syncFail || "Failed to sync goal. Check if you are on the creator live page.";
                        const actualErr = res.error || "Unknown Error";
                        const errLabel = uiTranslations[currentLang].errorLabel || "Error: ";
                        showToast(`${baseErr} (${actualErr})`, 5000);
                    }
                }
            }
        });
    }

    if (addTagBtn) {
        addTagBtn.onclick = () => {
            const tag = newTagInput.value.trim();
            if (tag && !goalTags.includes(tag)) {
                goalTags.push(tag);
                newTagInput.value = '';
                saveState();
                renderTagManagement();
                renderTagPerformance();
            }
        };
    }

    if (newTagInput) {
        newTagInput.onkeypress = (e) => {
            if (e.key === 'Enter') {
                addTagBtn.click();
            }
        };
    }

    if (tipsTabBtn) {
        tipsTabBtn.onclick = () => {
            console.log('[Fluxee] Tips tab clicked');
            if (tipsTabBtn) tipsTabBtn.classList.add('active');
            if (goalsTabBtn) goalsTabBtn.classList.remove('active');
            if (tipsTabContent) tipsTabContent.classList.add('active');
            if (goalsTabContent) goalsTabContent.classList.remove('active');
            if (clearAnalyticsBtn) clearAnalyticsBtn.style.display = 'block';
            renderAnalytics();
        };
    }

    if (goalsTabBtn) {
        goalsTabBtn.onclick = () => {
            console.log('[FanslyBot] Goals tab clicked');
            if (goalsTabBtn) goalsTabBtn.classList.add('active');
            if (tipsTabBtn) tipsTabBtn.classList.remove('active');
            if (goalsTabContent) goalsTabContent.classList.add('active');
            if (tipsTabContent) tipsTabContent.classList.remove('active');
            if (clearAnalyticsBtn) clearAnalyticsBtn.style.display = 'none';
            renderAll();
            if (typeof chrome !== 'undefined' && chrome.storage) {
                chrome.storage.local.get(['lastActiveGoals', 'goalsArchive'], (res) => {
                    if (res.lastActiveGoals) renderLiveGoals(res.lastActiveGoals);
                    if (res.goalsArchive) {
                        goalsArchive = res.goalsArchive;
                        renderGoalsArchive(goalsArchive);
                        renderTagPerformance();
                    }
                });
            }
        };
    }

    if (saveGoalBtn) {
        saveGoalBtn.onclick = () => {
            analyticsGoal = { name: goalNameInput.value, amount: parseFloat(goalAmountInput.value) || 0 };
            saveState();
            renderAnalytics();
            showToast(uiTranslations[currentLang].goalUpdated || "Goal updated!");
        };
    }

    if (resetGoalBtn) {
        resetGoalBtn.onclick = () => {
            showConfirm(uiTranslations[currentLang].confirmGoalReset, () => {
                goalResetTimestamp = Date.now();
                analyticsGoal = { name: "", amount: 0 };
                if (goalNameInput) goalNameInput.value = "";
                if (goalAmountInput) goalAmountInput.value = "";
                if (displayGoalName) displayGoalName.textContent = uiTranslations[currentLang].none;
                saveState();
                renderAnalytics();
            });
        };
    }

    if (clearAnalyticsBtn) {
        clearAnalyticsBtn.onclick = () => {
            if (clearAnalyticsBtn) {
                showConfirm(uiTranslations[currentLang].confirmClear24h, () => {
                    last24hReset = Date.now();
                    saveState();
                    renderAnalytics();
                });
            }
        };
    }

    if (saveGoalPageBtn) {
        saveGoalPageBtn.onclick = () => {
            const name = goalTitleInputPage.value.trim();
            const text = goalTextInputPage.value.trim();
            const amount = parseFloat(goalTargetInputPage.value) || 0;
            if (!name) { showToast(uiTranslations[currentLang].pleaseEnterGoalTitle); return; }

            if (editingGoalId) {
                const goal = goals.find(g => g.id === editingGoalId);
                if (goal) { goal.name = name; goal.text = text; goal.amount = amount; }
            } else {
                goals.push({ id: generateId(), name, text, amount, timestamp: Date.now() });
            }
            saveState();
            renderGoalsList();
            clearGoalFields();
            showToast(uiTranslations[currentLang].goalUpdated || "Goal saved!");
        };
    }

    if (clearGoalPageBtn) {
        clearGoalPageBtn.onclick = () => clearGoalFields();
    }

    if (analyticsTimeframe) {
        analyticsTimeframe.onchange = renderAnalytics;
    }

    if (sortItem) {
        sortItem.onclick = () => { analyticsSort.column = 'item'; analyticsSort.direction = analyticsSort.direction === 'asc' ? 'desc' : 'asc'; renderAnalytics(); };
    }
    if (sortCount) {
        sortCount.onclick = () => { analyticsSort.column = 'count'; analyticsSort.direction = analyticsSort.direction === 'asc' ? 'desc' : 'asc'; renderAnalytics(); };
    }
    if (sortTotal) {
        sortTotal.onclick = () => { analyticsSort.column = 'total'; analyticsSort.direction = analyticsSort.direction === 'asc' ? 'desc' : 'asc'; renderAnalytics(); };
    }

    document.querySelectorAll('.lang-flag').forEach(flag => {
        flag.onclick = () => { applyLanguage(flag.dataset.lang); chrome.storage.local.set({ currentLang: flag.dataset.lang }); };
    });

    if (refreshConnBtn) {
        refreshConnBtn.onclick = () => {
            refreshConnBtn.classList.add('spinning');
            // Ask content script to re-run its identity check
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, { action: 'refresh_identity' });
                }
            });
            setTimeout(() => refreshConnBtn.classList.remove('spinning'), 1500);
        };
    }

    const openDesignerBtn = document.getElementById('openDesignerBtn');
    if (openDesignerBtn) {
        openDesignerBtn.onclick = () => {
            window.location.href = 'designer.html';
        };
    }
    const openAutoModBtn = document.getElementById('openAutoModBtn');
    if (openAutoModBtn) {
        openAutoModBtn.onclick = () => {
            window.location.href = 'automod.html';
        };
    }
}

// --- RENDERING LOGIC ---

function renderAnalytics() {
    if (!analyticsList) return;
    analyticsList.innerHTML = '';
    const timeframeValue = analyticsTimeframe.value;
    const now = Date.now();
    let cutoff = 0;

    if (timeframeValue === '24h') cutoff = Math.max(now - (24 * 60 * 60 * 1000), last24hReset);
    else if (timeframeValue === '7d') cutoff = now - (7 * 24 * 60 * 60 * 1000);
    else if (timeframeValue === '30d') cutoff = now - (30 * 24 * 60 * 60 * 1000);

    const filteredTips = tipAnalytics.filter(t => t.timestamp >= cutoff);

    let totalTipsCount = 0;
    let totalRevenueSum = 0;

    const aggregated = {};
    filteredTips.forEach(tip => {
        const amount = Number(tip.amount) || 0;
        if (!aggregated[tip.item]) {
            aggregated[tip.item] = { count: 0, total: 0 };
        }
        aggregated[tip.item].count += 1;
        aggregated[tip.item].total += amount;

        totalTipsCount += 1;
        totalRevenueSum += amount;
    });

    const avgTipValue = totalTipsCount > 0 ? (totalRevenueSum / totalTipsCount) : 0;

    analyticsNetRev.textContent = (totalRevenueSum * 0.8).toFixed(2);
    analyticsTotalRev.textContent = totalRevenueSum.toFixed(2);
    analyticsTotalTips.textContent = totalTipsCount;
    const analyticsAvgTip = document.getElementById('analyticsAvgTip');
    if (analyticsAvgTip) {
        analyticsAvgTip.textContent = avgTipValue.toFixed(2);
    }

    if (analyticsGoal && analyticsGoal.name) {
        displayGoalName.textContent = analyticsGoal.name;
        if (goalNameInput) goalNameInput.value = analyticsGoal.name;
        if (goalAmountInput) goalAmountInput.value = analyticsGoal.amount || "";
    } else {
        displayGoalName.textContent = uiTranslations[currentLang].none;
        if (goalNameInput) goalNameInput.value = "";
        if (goalAmountInput) goalAmountInput.value = "";
    }

    renderPeakHoursChart(filteredTips);

    // Goal calculation
    const goalTips = tipAnalytics.filter(t => t.timestamp >= goalResetTimestamp);
    const goalRevenueValue = goalTips.reduce((sum, tip) => sum + (Number(tip.amount) || 0), 0);
    renderGoalProgress(goalRevenueValue, analyticsGoal.amount || 0, analyticsGoal.name || uiTranslations[currentLang].none);

    // Identify Untipped
    renderUntippedItems(aggregated);

    // Update connection status
    updateConnectionStatus(currentChatRoomId);

    // Sorted Table
    const sortedItems = Object.keys(aggregated).map(key => ({
        item: key,
        count: aggregated[key].count,
        total: aggregated[key].total
    }));

    sortedItems.sort((a, b) => {
        const col = analyticsSort.column;
        const dir = analyticsSort.direction === 'asc' ? 1 : -1;
        if (col === 'item') return dir * a.item.localeCompare(b.item);
        if (col === 'count') return dir * (a.count - b.count);
        if (col === 'total') return dir * (a.total - b.total);
        return 0;
    });

    if (sortedItems.length === 0) {
        analyticsList.innerHTML = `<div class="empty-state">${uiTranslations[currentLang].noTipsTimeframe}</div>`;
    } else {
        sortedItems.forEach(data => {
            const row = document.createElement('div');
            row.className = 'table-row';
            row.innerHTML = `
                <div title="${data.item}">${data.item}</div>
                <div class="text-center">${data.count}</div>
                <div class="text-right">$${data.total.toFixed(2)}</div>
            `;
            analyticsList.appendChild(row);
        });
    }
}

function renderPeakHoursChart(tips) {
    if (!peakHoursChart) return;
    peakHoursChart.innerHTML = '';
    const targetHours = [19, 20, 21, 22, 23, 0, 1, 2];
    const hourLabels = ["7PM", "8PM", "9PM", "10PM", "11PM", "12AM", "1AM", "2AM"];
    const hourData = targetHours.map(() => 0);

    tips.forEach(tip => {
        const date = new Date(tip.timestamp);
        const hour = date.getHours();
        const idx = targetHours.indexOf(hour);
        if (idx !== -1) hourData[idx] += parseFloat(tip.amount || 0);
    });

    const maxVal = Math.max(...hourData, 1);
    hourData.forEach((val, i) => {
        const wrapper = document.createElement('div');
        wrapper.className = 'chart-bar-wrapper';
        const heightPercent = (val / maxVal) * 100;
        wrapper.innerHTML = `
            <div class="chart-bar" style="height: ${heightPercent}%" title="$${val.toFixed(2)}"></div>
            <div class="chart-label">${hourLabels[i]}</div>
        `;
        peakHoursChart.appendChild(wrapper);
    });
}

function renderGoalProgress(current, target, name) {
    if (!goalProgressBar) return;
    const percent = target > 0 ? Math.min((current / target) * 100, 100) : 0;
    goalProgressBar.style.width = `${percent}%`;
    goalProgressText.textContent = `$${current.toFixed(0)} / $${target} (${percent.toFixed(1)}%)`;

    if (percent >= 100 && target > 0) {
        goalProgressBar.classList.add('completed');
    } else {
        goalProgressBar.classList.remove('completed');
    }
}

function renderUntippedItems(aggregated) {
    if (!untippedList) return;
    const allPossibleItems = new Set();
    for (const id in menus) {
        const lines = (menus[id].content || "").split(/\r?\n/);
        lines.forEach(line => {
            const match = line.match(/\$([0-9]+)/);
            if (match) {
                const name = getMenuNameFromLine(line, match[1]);
                if (name) allPossibleItems.add(name);
            }
        });
    }
    const tippedKeys = new Set(Object.keys(aggregated));
    const untipped = [...allPossibleItems].filter(name => !tippedKeys.has(name)).sort();

    untippedList.innerHTML = '';
    if (untipped.length === 0) {
        untippedList.innerHTML = `<div class="empty-state">${uiTranslations[currentLang].allTipped}</div>`;
    } else {
        untipped.forEach(name => {
            const tag = document.createElement('span');
            tag.className = 'tag-item';
            tag.textContent = name;
            untippedList.appendChild(tag);
        });
    }
}

function getMenuNameFromLine(line, amount) {
    const amountIdx = line.indexOf(amount);
    if (amountIdx === -1) return null;
    const rawItem = line.substring(amountIdx + amount.length).replace(/^(t|tokens)\s*/i, '');
    const isRemovable = (char) => {
        if (!char) return false;
        const code = char.codePointAt(0);
        return (code === 0x20 || code === 0x2D || code === 0x3A || code === 0x24 || code >= 0x1F300);
    };
    let cleaned = rawItem.trim();
    while (cleaned.length > 0 && isRemovable(cleaned[0])) cleaned = cleaned.substring(1);
    while (cleaned.length > 0 && isRemovable(cleaned[cleaned.length - 1])) cleaned = cleaned.substring(0, cleaned.length - 1);
    return cleaned.trim() || null;
}

function renderLiveGoals(activeGoals) {
    if (!liveGoalsGlass) return;
    // Reset all slots first
    document.querySelectorAll('.live-slot').forEach(container => {
        const fill = container.querySelector('.slot-fill');
        const desc = container.querySelector('.lg-desc');
        const amount = container.querySelector('.lg-amount');
        if (fill) fill.style.width = '0%';
        if (desc) desc.textContent = '---';
        if (amount) amount.textContent = '$0 / $0';
    });

    (activeGoals || []).forEach((goal, index) => {
        let slotId = 3 - index;
        if (slotId < 1) return;
        const container = document.querySelector(`.live-slot[data-slot="${slotId}"]`);
        if (!container) return;
        const fill = container.querySelector('.slot-fill');
        const desc = container.querySelector('.lg-desc');
        const amount = container.querySelector('.lg-amount');

        const current = (goal.currentAmount || 0) / 1000;
        const target = (goal.goalAmount || 1) / 1000;
        const percent = Math.min((current / target) * 100, 100);

        if (fill) fill.style.width = `${percent}%`;
        if (desc) desc.textContent = goal.label || uiTranslations[currentLang].defaultLiveGoalLabel;
        if (amount) amount.textContent = `$${current.toLocaleString(undefined, { minimumFractionDigits: 2 })} / $${target.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
    });
}

function renderGoalsArchive(archive) {
    if (!goalsArchiveList) return;
    goalsArchiveList.innerHTML = '';
    const sorted = [...(archive || [])].sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

    if (sorted.length === 0) {
        goalsArchiveList.innerHTML = `<div class="empty-state">${uiTranslations[currentLang].noArchivedGoals}</div>`;
        return;
    }

    sorted.forEach(goal => {
        const row = document.createElement('div');
        row.className = 'table-row archive-row';
        const statusText = goal.status === 'reached' ? uiTranslations[currentLang].statusReached : uiTranslations[currentLang].statusFailed;
        const statusColor = goal.status === 'reached' ? '#00e5ff' : '#ff5252';

        row.innerHTML = `
            <div style="flex: 3;">
                <div class="archive-label">${goal.label || uiTranslations[currentLang].defaultLiveGoalLabel}</div>
                <div class="archive-tags" id="tags-${goal.id}"></div>
            </div>
            <div class="text-right" style="color: ${statusColor}">
                <div>${statusText}</div>
                <div class="archive-actions" style="margin-top: 5px;">
                    <span class="delete-archive-btn" style="cursor: pointer; opacity: 0.6; font-size: 14px;" title="${uiTranslations[currentLang].delete || 'Delete'}">🗑️</span>
                </div>
            </div>
        `;

        const delBtn = row.querySelector('.delete-archive-btn');
        if (delBtn) {
            delBtn.onclick = (e) => {
                e.stopPropagation();
                deleteArchivedGoal(goal.id);
            };
        }

        const tagsDiv = row.querySelector(`#tags-${goal.id}`);
        (goal.tags || []).forEach(tag => {
            const pill = document.createElement('span');
            pill.className = 'tag-pill';
            pill.textContent = tag;
            pill.onclick = () => {
                goal.tags = goal.tags.filter(t => t !== tag);
                saveState();
                renderGoalsArchive(goalsArchive);
                renderTagPerformance();
            };
            tagsDiv.appendChild(pill);
        });

        const addBtn = document.createElement('span');
        addBtn.className = 'add-tag-btn';
        addBtn.textContent = '+';
        addBtn.onclick = () => openTagPicker(goal.id);
        tagsDiv.appendChild(addBtn);

        goalsArchiveList.appendChild(row);
    });
}

function renderTagManagement() {
    if (!masterTagsList) return;
    masterTagsList.innerHTML = '';
    if (goalTags.length === 0) {
        masterTagsList.innerHTML = `<div class="empty-state">${uiTranslations[currentLang].noTagsYet}</div>`;
        return;
    }

    goalTags.forEach(tag => {
        const pill = document.createElement('span');
        pill.className = 'tag-pill master-tag';
        pill.innerHTML = `${tag} <span class="delete-x">×</span>`;
        pill.querySelector('.delete-x').onclick = (e) => {
            e.stopPropagation();
            deleteTag(tag);
        };
        masterTagsList.appendChild(pill);
    });
}

function deleteTag(tagName) {
    showConfirm(uiTranslations[currentLang].confirmDeleteTag.replace('{name}', tagName), () => {
        goalTags = goalTags.filter(t => t !== tagName);
        goalsArchive.forEach(g => {
            if (g.tags) g.tags = g.tags.filter(t => t !== tagName);
        });
        saveState();
        renderAll();
    });
}

function renderTagPerformance() {
    if (!tagPerformanceList) return;
    tagPerformanceList.innerHTML = '';
    const stats = {};
    goalTags.forEach(tag => stats[tag] = { usage: 0, wins: 0 });

    goalsArchive.forEach(goal => {
        (goal.tags || []).forEach(tag => {
            if (stats[tag]) {
                stats[tag].usage++;
                if (goal.status === 'reached') stats[tag].wins++;
            }
        });
    });

    const sortedTags = Object.keys(stats).sort((a, b) => stats[b].usage - stats[a].usage);
    if (sortedTags.length === 0) {
        tagPerformanceList.innerHTML = `<div class="empty-state">${uiTranslations[currentLang].noTagsDefined}</div>`;
        return;
    }

    sortedTags.forEach(tag => {
        const s = stats[tag];
        const winRate = s.usage > 0 ? Math.round((s.wins / s.usage) * 100) : 0;
        const row = document.createElement('div');
        row.className = 'table-row';
        row.innerHTML = `
            <div style="flex: 2;">${tag}</div>
            <div class="text-center">${s.usage}</div>
            <div class="text-right">${winRate}%</div>
        `;
        tagPerformanceList.appendChild(row);
    });
}

function deleteArchivedGoal(id) {
    const goal = goalsArchive.find(g => g.id === id);
    if (!goal) return;

    const confirmMsg = uiTranslations[currentLang].confirmDeleteGoalMsg || "Delete this archived goal?";
    showConfirm(confirmMsg.replace('{name}', goal.label || ""), () => {
        goalsArchive = goalsArchive.filter(g => g.id !== id);
        saveState();
        renderTagPerformance();
        renderGoalsArchive(goalsArchive);
    });
}

function renderGoalsList(lastActiveGoals) {
    if (!goalsListContainer) return;

    // If lastActiveGoals not passed in, fetch from storage first
    if (lastActiveGoals === undefined) {
        if (typeof chrome !== 'undefined' && chrome.storage) {
            chrome.storage.local.get(['lastActiveGoals'], (res) => {
                renderGoalsList(res.lastActiveGoals || []);
            });
        } else {
            renderGoalsList([]);
        }
        return;
    }

    // Build a set of currently live goal labels from Fansly
    const activeLiveLabels = new Set((lastActiveGoals || []).map(g => g.label).filter(Boolean));

    goalsListContainer.innerHTML = '';
    if (goals.length === 0) {
        goalsListContainer.innerHTML = `<div class="empty-state">${uiTranslations[currentLang].noSavedGoals}</div>`;
        return;
    }

    goals.forEach(goal => {
        const isActive = activeLiveLabels.has(goal.name); // declare first — used by dot AND syncBtn

        const item = document.createElement('div');
        item.className = 'goal-item-card card glass';
        item.style.marginBottom = '10px';

        const header = document.createElement('div');
        header.className = 'goal-header';
        header.onclick = () => item.classList.toggle('expanded');

        const title = document.createElement('span');
        title.className = 'goal-title';
        title.style.fontWeight = '700';

        // Status indicator dot — green if live on Fansly, grey if not
        const dot = document.createElement('span');
        dot.className = `goal-status-dot${isActive ? ' live' : ''}`;
        dot.title = isActive ? 'Live on Fansly' : 'Not currently synced';
        title.appendChild(dot);

        const star = document.createElement('span');
        star.className = `popular-star ${goal.isPopular ? 'active' : ''}`;
        star.textContent = goal.isPopular ? '⭐' : '☆';
        star.onclick = (e) => {
            e.stopPropagation();
            goal.isPopular = !goal.isPopular;
            saveState();
            renderGoalsList();
        };

        title.appendChild(star);
        const nameText = document.createTextNode(` ${goal.name}`);
        title.appendChild(nameText);
        header.appendChild(title);

        const actions = document.createElement('div');
        actions.className = 'goal-actions';
        actions.style.display = 'flex';
        actions.style.gap = '8px';

        const editBtn = document.createElement('button');
        editBtn.className = 'btn secondary small';
        editBtn.textContent = '✏️';
        editBtn.title = uiTranslations[currentLang].editGoal;
        editBtn.onclick = (e) => {
            e.stopPropagation();
            editGoal(goal.id);
        };

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'btn danger small';
        deleteBtn.textContent = '🗑️';
        deleteBtn.title = uiTranslations[currentLang].deleteGoal;
        deleteBtn.onclick = (e) => {
            e.stopPropagation();
            deleteGoal(goal.id);
        };

        actions.appendChild(editBtn);
        actions.appendChild(deleteBtn);
        header.appendChild(actions);

        const body = document.createElement('div');
        body.className = 'goal-body';

        const desc = document.createElement('div');
        desc.className = 'goal-desc';
        desc.style.fontSize = '12px';
        desc.style.color = '#ccc';
        desc.style.marginTop = '5px';
        desc.textContent = goal.text || uiTranslations[currentLang].noDescription;

        const amount = document.createElement('div');
        amount.className = 'goal-amount';
        amount.style.fontWeight = 'bold';
        amount.style.color = '#00e5ff';
        amount.style.fontSize = '13px';
        amount.style.marginTop = '5px';
        amount.textContent = `Target: $${(goal.amount || 0).toFixed(2)}`;

        const syncRow = document.createElement('div');
        syncRow.className = 'sync-row';
        syncRow.style.marginTop = '10px';
        syncRow.style.display = 'flex';
        syncRow.style.gap = '5px';

        const syncBtn = document.createElement('button');
        syncBtn.className = `btn primary small${isActive ? ' sync-btn-active' : ''}`;
        syncBtn.style.fontSize = '11px';
        syncBtn.style.padding = '5px 12px';
        syncBtn.textContent = uiTranslations[currentLang].syncGoal || '📡 Sync to Fansly';
        syncBtn.title = isActive ? '✅ This goal is currently live on Fansly' : 'Post this goal to Fansly';
        syncBtn.onclick = (e) => {
            e.stopPropagation();
            handleSyncGoal(goal.id);
        };
        syncRow.appendChild(syncBtn);

        // Add to Queue button — only if not live and not already in queue
        const queuePos = goalQueue.indexOf(goal.id);
        if (!isActive) {
            const queueBtn = document.createElement('button');
            if (queuePos === -1) {
                queueBtn.className = 'btn secondary small';
                queueBtn.textContent = '⏳ Queue';
                queueBtn.title = 'Add to the auto-sync queue';
                queueBtn.onclick = (e) => { e.stopPropagation(); addToQueue(goal.id); };
            } else {
                queueBtn.className = 'btn small queue-dequeue-btn';
                queueBtn.textContent = `#${queuePos + 1} ✕`;
                queueBtn.title = `Remove from queue (currently #${queuePos + 1})`;
                queueBtn.onclick = (e) => { e.stopPropagation(); removeFromQueue(goal.id); };
            }
            syncRow.appendChild(queueBtn);
        }

        body.appendChild(desc);
        body.appendChild(amount);
        body.appendChild(syncRow);

        item.appendChild(header);
        item.appendChild(body);
        goalsListContainer.appendChild(item);
    });

    // Render the queue panel below the goal list
    renderQueuePanel();
}

function generateId() {
    return Math.random().toString(36).substr(2, 9);
}

// ---- Goal Queue Helpers ----

function saveQueue() {
    if (typeof chrome !== 'undefined' && chrome.storage)
        chrome.storage.local.set({ goalQueue });
}

function addToQueue(id) {
    if (goalQueue.includes(id)) return;
    goalQueue.push(id);
    saveQueue();
    renderGoalsList();
}

function removeFromQueue(id) {
    goalQueue = goalQueue.filter(qid => qid !== id);
    saveQueue();
    renderGoalsList();
}

function moveQueueItem(id, direction) {
    const idx = goalQueue.indexOf(id);
    if (idx === -1) return;
    const newIdx = idx + direction;
    if (newIdx < 0 || newIdx >= goalQueue.length) return;
    [goalQueue[idx], goalQueue[newIdx]] = [goalQueue[newIdx], goalQueue[idx]];
    saveQueue();
    renderQueuePanel();
}

function renderQueuePanel() {
    // Remove existing panel if any
    const existing = document.getElementById('goalQueuePanel');
    if (existing) existing.remove();
    if (goalQueue.length === 0) return;

    const panel = document.createElement('div');
    panel.id = 'goalQueuePanel';
    panel.className = 'goal-queue-panel';

    const title = document.createElement('div');
    title.className = 'queue-panel-title';
    title.innerHTML = `🟠 Auto-Sync Queue <span class="queue-count">${goalQueue.length} waiting</span>`;
    panel.appendChild(title);

    goalQueue.forEach((id, index) => {
        const goal = goals.find(g => g.id === id);
        if (!goal) return;

        const row = document.createElement('div');
        row.className = 'queue-item-row';

        const badge = document.createElement('span');
        badge.className = 'queue-position-badge';
        badge.textContent = `#${index + 1}`;

        const name = document.createElement('span');
        name.className = 'queue-item-name';
        name.textContent = goal.name;

        const controls = document.createElement('div');
        controls.className = 'queue-item-controls';

        const upBtn = document.createElement('button');
        upBtn.className = 'btn small queue-arrow-btn';
        upBtn.textContent = '↑';
        upBtn.disabled = index === 0;
        upBtn.title = 'Move up';
        upBtn.onclick = () => moveQueueItem(id, -1);

        const downBtn = document.createElement('button');
        downBtn.className = 'btn small queue-arrow-btn';
        downBtn.textContent = '↓';
        downBtn.disabled = index === goalQueue.length - 1;
        downBtn.title = 'Move down';
        downBtn.onclick = () => moveQueueItem(id, 1);

        const removeBtn = document.createElement('button');
        removeBtn.className = 'btn small queue-remove-btn';
        removeBtn.textContent = '✕';
        removeBtn.title = 'Remove from queue';
        removeBtn.onclick = () => removeFromQueue(id);

        controls.appendChild(upBtn);
        controls.appendChild(downBtn);
        controls.appendChild(removeBtn);

        row.appendChild(badge);
        row.appendChild(name);
        row.appendChild(controls);
        panel.appendChild(row);
    });

    goalsListContainer.prepend(panel);
}


function editGoal(id) {
    const goal = goals.find(g => g.id === id);
    if (!goal) return;
    editingGoalId = id;
    goalTitleInputPage.value = goal.name;
    goalTextInputPage.value = goal.text;
    goalTargetInputPage.value = goal.amount;
    goalTitleInputPage.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function deleteGoal(id) {
    const goal = goals.find(g => g.id === id);
    if (!goal) return;
    showConfirm(uiTranslations[currentLang].confirmDeleteGoalMsg.replace('{name}', goal.name), () => {
        goals = goals.filter(g => g.id !== id);
        if (editingGoalId === id) clearGoalFields();
        saveState();
        renderGoalsList();
    });
}

function handleSyncGoal(id) {
    const goal = goals.find(g => g.id === id);
    if (!goal) return;
    chrome.runtime.sendMessage({
        action: 'sync_goal_to_fansly',
        goal: {
            label: goal.name,
            goalAmount: Math.round((goal.amount || 0) * 1000), // Fansly uses millicents
            description: goal.text || ""
        }
    }, (response) => {
        if (chrome.runtime.lastError) {
            console.warn('[FanslyBot] Sync message sent, but connection closed. (Expected for long-running syncs)');
        }
    });
}

function clearGoalFields() {
    editingGoalId = null;
    goalTitleInputPage.value = "";
    goalTextInputPage.value = "";
    goalTargetInputPage.value = "";
}

// --- INTERACTIVE EVENTS ---

// Handlers moved to initHandlers()

// Handlers moved to initHandlers()


// --- MESSAGING & STORAGE SYNC ---

chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local') {
        if (changes.tipAnalytics || changes.last24hReset || changes.goalResetTimestamp || changes.analyticsGoal) {
            chrome.storage.local.get(['tipAnalytics', 'last24hReset', 'goalResetTimestamp', 'analyticsGoal'], (res) => {
                tipAnalytics = res.tipAnalytics || [];
                last24hReset = res.last24hReset || 0;
                goalResetTimestamp = res.goalResetTimestamp || 0;
                analyticsGoal = res.analyticsGoal || { name: "", amount: 0 };
                renderAnalytics();
                updateConnectionStatus(res.chatRoomId);
            });
        }
        if (changes.chatRoomId) {
            currentChatRoomId = changes.chatRoomId.newValue;
            updateConnectionStatus(currentChatRoomId);
        }
        if (changes.lastActiveGoals) renderLiveGoals(changes.lastActiveGoals.newValue);
        if (changes.goalsArchive) {
            goalsArchive = changes.goalsArchive.newValue;
            renderGoalsArchive(goalsArchive);
            renderTagPerformance();
        }
        if (changes.goals) {
            goals = changes.goals.newValue;
            renderGoalsList();
        }
        if (changes.lastActiveGoals) {
            // Re-render goal list so sync button highlights update live
            renderGoalsList(changes.lastActiveGoals.newValue || []);
        }
        if (changes.goalQueue) {
            // Queue updated by background auto-sync — refresh queue panel and cards
            goalQueue = changes.goalQueue.newValue || [];
            renderGoalsList();
        }
    }
});

chrome.runtime.onMessage.addListener((request) => {
    if (request.action === 'tip_analytics_updated') {
        tipAnalytics = request.tipAnalytics;
        renderAnalytics();
    } else if (request.action === 'active_goals_updated') {
        renderLiveGoals(request.data);
        if (request.archive) {
            goalsArchive = request.archive;
            renderGoalsArchive(goalsArchive);
            renderTagPerformance();
        }
    }
});

// Modal Helpers
function openTagPicker(goalId) {
    currentTaggingGoalId = goalId;
    const goal = goalsArchive.find(g => g.id === goalId);
    const existing = goal?.tags || [];

    const list = document.getElementById('tagPickerList');
    list.innerHTML = '';
    goalTags.forEach(tag => {
        const item = document.createElement('div');
        item.className = 'modal-tag-item';
        const isChecked = existing.includes(tag);
        item.innerHTML = `<input type="checkbox" ${isChecked ? 'checked' : ''}> <span>${tag}</span>`;
        item.onclick = (e) => {
            const cb = item.querySelector('input');
            if (e.target !== cb) cb.checked = !cb.checked;
            toggleTag(tag, cb.checked);
        };
        list.appendChild(item);
    });
    document.getElementById('tagPickerModal').style.display = 'flex';
}

function toggleTag(tag, isChecked) {
    const goal = goalsArchive.find(g => g.id === currentTaggingGoalId);
    if (!goal) return;
    if (!goal.tags) goal.tags = [];
    if (isChecked && !goal.tags.includes(tag)) goal.tags.push(tag);
    else if (!isChecked) goal.tags = goal.tags.filter(t => t !== tag);
    saveState();
    renderGoalsArchive(goalsArchive);
    renderTagPerformance();
}

document.getElementById('closeTagPickerBtn').onclick = () => document.getElementById('tagPickerModal').style.display = 'none';

function updateConnectionStatus(chatRoomId) {
    if (!connectionStatus) return;
    const statusText = document.getElementById('connStatusText');
    if (chatRoomId) {
        connectionStatus.classList.remove('offline');
        connectionStatus.classList.add('online');
        if (statusText) statusText.innerText = uiTranslations[currentLang].statusOnline || 'Connected';
    } else {
        connectionStatus.classList.remove('online');
        connectionStatus.classList.add('offline');
        if (statusText) statusText.innerText = uiTranslations[currentLang].statusOffline || 'Disconnected';
    }
}

// Initial status check
if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.get(['chatRoomId'], (res) => updateConnectionStatus(res.chatRoomId));
}

document.addEventListener('DOMContentLoaded', loadState);

// 🐣 April Fools Easter Egg: swap the banner logo on April 1st only
document.addEventListener('DOMContentLoaded', () => {
    const now = new Date();
    if (now.getMonth() === 3 && now.getDate() === 1) { // Month is 0-indexed: 3 = April
        const logo = document.querySelector('img.logo');
        if (logo) {
            logo.src = 'debug3103.png';
            logo.title = "🐣 Happy April Fools'!";
        }
    }
});
